﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

namespace TruckWebApp
{
    public partial class Login : System.Web.UI.Page
    {
        MySqlConnection con = new MySqlConnection(@"Data Source = localhost;port=3306;Initial Catalog=soa;User ID=root;Password=root");
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void loginButton_Click(object sender, EventArgs e)
        {
            con.Open();
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from soa.login where username='" + username.Text + "'and password='" + password.Text + "'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
           // foreach(DataRow dr in dt.Rows)
           if(dt.Rows.Count==1)
            {
                DataRow dr = dt.Rows[0];
                Session["username"] = dr["username"].ToString();
                Session["labelResult"] = "";
                if (Session["username"].ToString() == "admin")
                {
                    Response.Redirect("Admin/AdminLandingPage.aspx");
                }
                else
                {
                    Response.Redirect("Customer/CustomerLandPage.aspx");
                }
            }
            else
            {
                loginLabel.Text = "Invalid Username and password";
            }
            con.Close();
            
        }

        protected void username_TextChanged(object sender, EventArgs e)
        {

        }

        protected void signUpBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("/SignUpPage.aspx");
        }
    }
}