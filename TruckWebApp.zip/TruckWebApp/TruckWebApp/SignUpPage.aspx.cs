﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;
namespace TruckWebApp
{
    public partial class SignUpPage : System.Web.UI.Page
    {
        MySqlConnection con = new MySqlConnection(@"Data Source = localhost;port=3306;Initial Catalog=soa;User ID=root;Password=root");
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Submit_Click(object sender, EventArgs e)
        {
            con.Open();
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            
            TruckWebServiceReference.TruckCatalogClient client = new TruckWebServiceReference.TruckCatalogClient();
            TruckWebServiceReference.customer cIdResult = new TruckWebServiceReference.customer();
            String user = "";
            String pwd = "";
            Boolean uname = false;
            Boolean fpwd = false;
            Boolean spwd = false;
            Boolean adss = false;
            Boolean busName = false;
            Boolean postalcode = false;
            Boolean pNum = false;
            if (Username.Text == null || Username.Text == "")
            {
                Response.Write("Username cannot be blank !");
            }
            else
            {
                cmd.CommandText = "Select * from soa.login where username='" + Username.Text + "'";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.Fill(dt);
                // foreach(DataRow dr in dt.Rows)
                if (dt.Rows.Count == 1)
                {
                    Response.Write("Username exists !. Try different user   ");
                }
                else
                {
                    cIdResult.customerID = Username.Text;
                    user = Username.Text;
                    uname = true;
                }

            }
            if (password.Text == null || password.Text == "")
            {
                Response.Write("Password cannot be blank !   ");
            }
            else
            {
                if (cpassword.Text != password.Text)
                {
                    Response.Write("Password does not match !   ");
                }
                else
                {
                    pwd = password.Text;
                    fpwd = true;
                }
            }
            cIdResult.title = DropDownList1.SelectedItem.Text;
            if (bName.Text == null || bName.Text == "")
            {
                Response.Write("BusinessName cannot be blank !   ");
            }
            else
            {
                cIdResult.businessName = bName.Text;
                busName = true;
            }
            if (address.Text == null || address.Text == "")
            {
                Response.Write("Address cannot be blank !    ");
            }
            else
            {
                cIdResult.address = address.Text;
                adss = true;
            }
            if (city.Text == null || city.Text == "")
            {
                Response.Write("City cannot be blank !    ");
            }
            else
            {
                cIdResult.city = city.Text;
            }
            if (state.Text == null || state.Text == "")
            {
                Response.Write("State cannot be blank !    ");
            }
            else
            {
                cIdResult.state = state.Text;
            }
            if (PostalCode.Text == null || PostalCode.Text == "" || PostalCode.Text.Length > 6)
            {
                Response.Write("Postalcode cannot be blank or more than 6 digits!  ");
            }
            else
            {
                cIdResult.postalCode = Convert.ToInt32(PostalCode.Text);
                postalcode = true;
            }
            if (pNumber.Text == null || pNumber.Text == "")
            {
                Response.Write("Phone Number cannot be blank     ");
            }
            else
            {
                cIdResult.phoneNumber = pNumber.Text;
            }

            cIdResult.cellNumber = celNumber.Text;
            cIdResult.otherNumber = oNumber.Text;
            cIdResult.emailAddress = email.Text;
            cIdResult.country = country.Text;
            cIdResult.type = typeId.Text;
            cIdResult.name = compName.Text;
            cIdResult.contactName = contcat.Text;

            if (uname && fpwd && adss && busName && postalcode)
            {
                cmd.CommandText = "insert into soa.login values('" + Username.Text + "','" + password.Text + "')";
                cmd.ExecuteNonQuery();
                Boolean result = client.createCustomer(cIdResult);
                if (result)
                {
                    Response.Write("    User Created successfully. Click Cancel");
                }
                else
                {
                    Response.Write("   User Creation failed. Contact system administrators");
                }

            }
            con.Close();
        }

        protected void Cancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Login.aspx");
        }
    }
}