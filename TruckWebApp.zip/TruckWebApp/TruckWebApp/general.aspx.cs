﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TruckWebApp
{
    public partial class general : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["username"].ToString() == "admin")
            {
                genLabel.Text = "Welcome Admin";
                
            }
            else
            {
                genLabel.Text = "Welcome Customer";
            }
        }
    }
}