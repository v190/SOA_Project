﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TruckWebApp.Customer
{
    public partial class UpdateCustomer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Page customerLandPage = (Page)Context.Handler;
            if (!IsPostBack)
            {
                 TruckWebServiceReference.TruckCatalogClient client = new TruckWebServiceReference.TruckCatalogClient();
                 TruckWebServiceReference.customer cIdResult = new TruckWebServiceReference.customer();
                 cIdResult = client.getCustomerByID(Session["username"].ToString().Trim());
                 Title1.Text = cIdResult.title;
                 BusinessName.Text = cIdResult.businessName;
                 Address.Text = cIdResult.address;
                 City.Text = cIdResult.city;
                state.Text = cIdResult.state;
                PostalCode.Text = cIdResult.postalCode.ToString();
                Country.Text = cIdResult.country;
                 PhoneNumber.Text = cIdResult.phoneNumber;
                CellNumber.Text = cIdResult.cellNumber;
                OtherNumber.Text = cIdResult.otherNumber;
                FaxNumber.Text = cIdResult.faxNumber;
                Email.Text = cIdResult.emailAddress;
                ContactName.Text = cIdResult.contactName;
                AlternateContactName.Text = cIdResult.alternateContactName;
                //DateEntered.Text = cIdResult.dateEntered.ToString();
            }
        }

        protected void UpdateBtn_Click(object sender, EventArgs e)
        {
            TruckWebServiceReference.TruckCatalogClient client = new TruckWebServiceReference.TruckCatalogClient();
            TruckWebServiceReference.customer cIdResult = new TruckWebServiceReference.customer();
            cIdResult.title = Title1.Text;
            cIdResult.businessName = BusinessName.Text;
            cIdResult.address = Address.Text;
            cIdResult.city = City.Text;
            cIdResult.state = state.Text;
            cIdResult.postalCode = Convert.ToInt32(PostalCode.Text);
            cIdResult.country = Country.Text;
            cIdResult.phoneNumber = PhoneNumber.Text;
            cIdResult.cellNumber = CellNumber.Text;
            cIdResult.otherNumber = OtherNumber.Text;
            cIdResult.faxNumber = FaxNumber.Text;
            cIdResult.emailAddress = Email.Text;
            cIdResult.contactName = ContactName.Text;
            cIdResult.alternateContactName = AlternateContactName.Text;
            cIdResult.customerID= Session["username"].ToString().Trim();

            //Call Update service
            String result = client.updateCustomer(cIdResult);
            Session["labelResult"] = result;
            Response.Redirect("/Customer/CustomerLandPage.aspx");
            //Server.Transfer("/Customer/CustomerLandPage.aspx");
        }

        protected void Cancelbtn_Click(object sender, EventArgs e)
        {
            Session["labelResult"] = "";
            Response.Redirect("/Customer/CustomerLandPage.aspx");
        }
    }
}