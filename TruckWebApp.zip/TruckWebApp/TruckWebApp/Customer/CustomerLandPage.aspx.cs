﻿using System;
using System.Collections;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TruckWebApp.Customer
{
    public partial class CustomerLandPage : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            welcomeLabel.Text = "Welcome " + Session["username"].ToString();
            result.Text= Session["labelResult"].ToString();
            //Page lastPage = (Page)Context.Handler;
            //result.Text = ((Label)lastPage.FindControl("resultLabel")).Text;
        }

        protected void ViewProfile_Click(object sender, EventArgs e)
        {
            TruckWebServiceReference.TruckCatalogClient client = new TruckWebServiceReference.TruckCatalogClient();
            TruckWebServiceReference.customer cIdResult = new TruckWebServiceReference.customer();
            cIdResult = client.getCustomerByID(Session["username"].ToString().Trim());
            DataTable dt = new DataTable();
            dt.Columns.Add("CustomerID");
            dt.Columns.Add("Title");
            dt.Columns.Add("BusinessName");
            dt.Columns.Add("Address");
            dt.Columns.Add("City");
            dt.Columns.Add("PhoneNumber");
            dt.Rows.Add();
            dt.Rows[0]["CustomerID"] = cIdResult.customerID;
            dt.Rows[0]["Title"] = cIdResult.title;
            dt.Rows[0]["BusinessName"] = cIdResult.businessName;
            dt.Rows[0]["Address"] = cIdResult.address;
            dt.Rows[0]["City"] = cIdResult.city;
            dt.Rows[0]["PhoneNumber"] = cIdResult.phoneNumber;
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

        protected void ViewOrders_Click(object sender, EventArgs e)
        {
            TruckWebServiceReference.TruckCatalogClient client = new TruckWebServiceReference.TruckCatalogClient();
            var list =client.getCustomerOrders(Session["username"].ToString().Trim());
            if (list == null)
            {
                Session["labelResult"] = "No orders to view";
            }
            else
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("OrderID");
                dt.Columns.Add("OrderDate");
                dt.Columns.Add("CustomerID");
                dt.Columns.Add("EmployeeID");
                dt.Columns.Add("TruckID");
                dt.Columns.Add("IsSpecial");
                dt.Columns.Add("PurchaseOrderNumber");
                dt.Columns.Add("OrderTotalAmount");

                for (int i = 0; i < list.Count(); i++)
                {
                    dt.Rows.Add();
                    dt.Rows[i]["OrderID"] = list[i].orderID;
                    dt.Rows[i]["OrderDate"] = list[i].orderDate;
                    dt.Rows[i]["CustomerID"] = list[i].customerID;
                    dt.Rows[i]["EmployeeID"] = list[i].employeeID;
                    dt.Rows[i]["TruckID"] = list[i].truckID;
                    dt.Rows[i]["IsSpecial"] = list[i].isSpecial;
                    dt.Rows[i]["PurchaseOrderNumber"] = list[i].purchaseOrderNumber;
                    dt.Rows[i]["orderTotalAmount"] = list[i].orderTotalAmount;
                }
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
            
        }

        protected void UpdateProfile_Click(object sender, EventArgs e)
        {
            Server.Transfer("/Customer/UpdateCustomer.aspx");
        }

        protected void deleteProfile_Click(object sender, EventArgs e)
        {
            //Page.ClientScript.RegisterStartupScript(this.GetType(),"Scripts","<script>alert('Are you sure?')</script>");
            //Session["labelResult"] = "Deleted";
            TruckWebServiceReference.TruckCatalogClient client = new TruckWebServiceReference.TruckCatalogClient();
            Boolean confirm=client.deleteCustomer(Session["username"].ToString().Trim());
            if (confirm)
            {
                Response.Redirect("/logout.aspx");
            }
            else
                Session["labelResult"] = "Operation failed. Contact system administrator";
        }

        protected void logoutButton_Click(object sender, EventArgs e)
        {
            Response.Redirect("/logout.aspx");
        }
    }
}