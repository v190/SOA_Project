﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TruckWebApp.Admin
{
    public partial class OtherServicesPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void orders_Click(object sender, EventArgs e)
        {
            TruckWebServiceReference.TruckCatalogClient client = new TruckWebServiceReference.TruckCatalogClient();
            var list = client.getAllOrders();
            if (list == null)
            {
                Response.Write("No results for the given values");
            }
            else
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("OrderID");
                dt.Columns.Add("CustomerID");
                dt.Columns.Add("EmployeeID");
                dt.Columns.Add("TruckID");
                dt.Columns.Add("IsSpecial");
                dt.Columns.Add("PurchaseOrderNumber");
                dt.Columns.Add("OrderTotalAmount");

                for (int i = 0; i < list.Count(); i++)
                {
                    dt.Rows.Add();
                    dt.Rows[i]["OrderID"] = list[i].orderID;
                    dt.Rows[i]["CustomerID"] = list[i].customerID;
                    dt.Rows[i]["EmployeeID"] = list[i].employeeID;
                    dt.Rows[i]["TruckID"] = list[i].truckID;
                    dt.Rows[i]["IsSpecial"] = list[i].isSpecial;
                    dt.Rows[i]["PurchaseOrderNumber"] = list[i].purchaseOrderNumber;
                    dt.Rows[i]["OrderTotalAmount"] = list[i].orderTotalAmount;
                }
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
        }

        protected void trucks_Click(object sender, EventArgs e)
        {
            TruckWebServiceReference.TruckCatalogClient client = new TruckWebServiceReference.TruckCatalogClient();
            var list = client.getAllTrucks();
            if (list == null)
            {
                Response.Write("No results for the given values");
            }
            else
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("TruckNo");
                dt.Columns.Add("Make");
                dt.Columns.Add("Year");
                dt.Columns.Add("Model");
                dt.Columns.Add("LicensePlateNo");
                dt.Columns.Add("EmployeeID");
                dt.Columns.Add("Color");
                dt.Columns.Add("Vin");

                for (int i = 0; i < list.Count(); i++)
                {
                    dt.Rows.Add();
                    dt.Rows[i]["TruckNo"] = list[i].truckNo;
                    dt.Rows[i]["Make"] = list[i].make;
                    dt.Rows[i]["Year"] = list[i].year;
                    dt.Rows[i]["Model"] = list[i].model;
                    dt.Rows[i]["LicensePlateNo"] = list[i].licensePlateNo;
                    dt.Rows[i]["EmployeeID"] = list[i].employeeID;
                    dt.Rows[i]["Color"] = list[i].color;
                    dt.Rows[i]["Vin"] = list[i].vin;
                }
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
        }

        protected void locations_Click(object sender, EventArgs e)
        {
            TruckWebServiceReference.TruckCatalogClient client = new TruckWebServiceReference.TruckCatalogClient();
            var list = client.getAllLocation();
            if (list == null)
            {
                Response.Write("No results for the given values");
            }
            else
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("LocationID");
                dt.Columns.Add("CustomerID");
                dt.Columns.Add("LocName");
                dt.Columns.Add("LocationCode");
                dt.Columns.Add("IsAuction");
                dt.Columns.Add("AddressStreet1");
                dt.Columns.Add("AddressStreet2");
                dt.Columns.Add("City");
                dt.Columns.Add("State");
                dt.Columns.Add("PostalCode");
                dt.Columns.Add("Region");
                dt.Columns.Add("LocationContactName");
                dt.Columns.Add("LocPhone");
                dt.Columns.Add("LocFaxNumber");
                dt.Columns.Add("LocEmail");

                for (int i = 0; i < list.Count(); i++)
                {
                    dt.Rows.Add();
                    dt.Rows[i]["LocationID"] = list[i].locationID;
                    dt.Rows[i]["CustomerID"] = list[i].customerID;
                    dt.Rows[i]["LocName"] = list[i].locName;
                    dt.Rows[i]["LocationCode"] = list[i].locationCode;
                    dt.Rows[i]["IsAuction"] = list[i].isAuction;
                    dt.Rows[i]["AddressStreet1"] = list[i].addressStreet1;
                    dt.Rows[i]["AddressStreet2"] = list[i].addressStreet2;
                    dt.Rows[i]["City"] = list[i].city;
                    dt.Rows[i]["State"] = list[i].state;
                    dt.Rows[i]["PostalCode"] = list[i].postalCode;
                    dt.Rows[i]["Region"] = list[i].region;
                    dt.Rows[i]["LocationContactName"] = list[i].locationContactName;
                    dt.Rows[i]["LocPhone"] = list[i].locPhone;
                    dt.Rows[i]["LocFaxNumber"] = list[i].locFaxNumber;
                    dt.Rows[i]["LocEmail"] = list[i].locEmail;
                }
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
        }

        protected void comments_Click(object sender, EventArgs e)
        {
            TruckWebServiceReference.TruckCatalogClient client = new TruckWebServiceReference.TruckCatalogClient();
            var list = client.getAllComments();
            if (list == null)
            {
                Response.Write("No results for the given values");
            }
            else
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("CommentID");
                dt.Columns.Add("CustomerID");
                dt.Columns.Add("LocationID");
                dt.Columns.Add("TransactionID");
                dt.Columns.Add("CommentTime");
                dt.Columns.Add("CommentLine");

                for (int i = 0; i < list.Count(); i++)
                {
                    dt.Rows.Add();
                    dt.Rows[i]["CommentID"] = list[i].commentID;
                    dt.Rows[i]["CustomerID"] = list[i].customerID;
                    dt.Rows[i]["LocationID"] = list[i].locationID;
                    dt.Rows[i]["TransactionID"] = list[i].transactionID;
                    dt.Rows[i]["CommentTime"] = list[i].commentTime;
                    dt.Rows[i]["CommentLine"] = list[i].commentLine;
                }
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
        }

        protected void Expenses_Click(object sender, EventArgs e)
        {
            TruckWebServiceReference.TruckCatalogClient client = new TruckWebServiceReference.TruckCatalogClient();
            var list = client.getAllExpenses();
            if (list == null)
            {
                Response.Write("No results for the given values");
            }
            else
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("ExpenseID");
                dt.Columns.Add("EmployeeID");
                dt.Columns.Add("ExpenseType");
                dt.Columns.Add("PurposeofExpense");
                dt.Columns.Add("AmountSpent");
                dt.Columns.Add("Description");
                dt.Columns.Add("AdvanceAmount");
                dt.Columns.Add("PaymentMethod");

                for (int i = 0; i < list.Count(); i++)
                {
                    dt.Rows.Add();
                    dt.Rows[i]["ExpenseID"] = list[i].expenseID;
                    dt.Rows[i]["EmployeeID"] = list[i].employeeID;
                    dt.Rows[i]["ExpenseType"] = list[i].expenseID;
                    dt.Rows[i]["PurposeofExpense"] = list[i].purposeofExpense;
                    dt.Rows[i]["AmountSpent"] = list[i].amountSpent;
                    dt.Rows[i]["Description"] = list[i].description;
                    dt.Rows[i]["AdvanceAmount"] = list[i].advanceAmount;
                    dt.Rows[i]["PaymentMethod"] = list[i].paymentMethod;
                }
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            TruckWebServiceReference.TruckCatalogClient client = new TruckWebServiceReference.TruckCatalogClient();
            var list = client.getAllPricing();
            if (list == null)
            {
                Response.Write("No results for the given values");
            }
            else
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("PriceID");
                dt.Columns.Add("Price");
                dt.Columns.Add("LocationIDFrom");
                dt.Columns.Add("LocationIDTo");
                dt.Columns.Add("LocationCodeFrom");
                dt.Columns.Add("LocationCodeTo");
                dt.Columns.Add("LocationNameFrom");
                dt.Columns.Add("LocationNameTo");
                dt.Columns.Add("CustomerID");

                for (int i = 0; i < list.Count(); i++)
                {
                    dt.Rows.Add();
                    dt.Rows[i]["PriceID"] = list[i].priceID;
                    dt.Rows[i]["Price"] = list[i].price;
                    dt.Rows[i]["LocationIDFrom"] = list[i].locationIDFrom;
                    dt.Rows[i]["LocationIDTo"] = list[i].locationIDTo;
                    dt.Rows[i]["LocationCodeFrom"] = list[i].locationCodeFrom;
                    dt.Rows[i]["LocationCodeTo"] = list[i].locationCodeTo;
                    dt.Rows[i]["LocationNameFrom"] = list[i].locationNameFrom;
                    dt.Rows[i]["LocationNameTo"] = list[i].locationNameTo;
                    dt.Rows[i]["CustomerID"] = list[i].customerID;
                }
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
        }

        protected void homeBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminLandingPage.aspx");
        }
    }
}