﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TruckWebApp.Admin
{
    public partial class DeleteEmployee : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void delete_Click(object sender, EventArgs e)
        {
            TruckWebServiceReference.TruckCatalogClient client = new TruckWebServiceReference.TruckCatalogClient();
            TruckWebServiceReference.employee emp = new TruckWebServiceReference.employee();
            emp = client.getEmployeeByID(empId.Text.Trim());
            if(emp.employeeID==null && emp.employeeID == "")
            {
                Response.Write("No user with the records!!");
            }
            else
            {
                Boolean confirm = client.deleteEmployee(empId.Text.Trim());
                if (confirm)
                {
                    Response.Write("Deleted successfully... Click cancel");
                }
                else
                    Response.Write("Operation failed. Contact system administrator");
            }
            
        }

        protected void Cancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminEmployeeMgmtpage.aspx");
        }
    }
}