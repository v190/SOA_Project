﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TruckWebApp.Admin
{
    public partial class CustomerSearch : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Search_Click(object sender, EventArgs e)
        {
            
            TruckWebServiceReference.TruckCatalogClient client = new TruckWebServiceReference.TruckCatalogClient();
            var list = client.customCustomerView(cID.Text.Trim(),phone.Text,bName.Text,email.Text,cName.Text);
            if (list == null)
            {
                GridView1.DataSource = null;
                GridView1.DataBind();
                Response.Write("No results for the given values");
            }
            else
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("CustomerID");
                dt.Columns.Add("Title");
                dt.Columns.Add("BusinessName");
                dt.Columns.Add("Address");
                dt.Columns.Add("City");
                dt.Columns.Add("PhoneNumber");
                for (int i = 0; i < list.Count(); i++)
                {
                    dt.Rows.Add();
                    dt.Rows[i]["CustomerID"] = list[i].customerID;
                    dt.Rows[i]["Title"] = list[i].title;
                    dt.Rows[i]["BusinessName"] = list[i].businessName;
                    dt.Rows[i]["Address"] = list[i].address;
                    dt.Rows[i]["City"] = list[i].city;
                    dt.Rows[i]["PhoneNumber"] = list[i].phoneNumber;
                }
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
            
        }

        protected void Back_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminCustomerMgmtPage.aspx");
        }
    }
}