﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TruckWebApp.Admin
{
    public partial class AddEmployee : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Submit_Click(object sender, EventArgs e)
        {
            TruckWebServiceReference.TruckCatalogClient client = new TruckWebServiceReference.TruckCatalogClient();
            TruckWebServiceReference.employee c = new TruckWebServiceReference.employee();
            TruckWebServiceReference.employee cIdResult = new TruckWebServiceReference.employee();
            Boolean fname = false;
            Boolean lname = false;
            Boolean eId = false;
            Boolean mail = false;
            Boolean cPhone = false;
            Boolean title = false;
            Boolean ssn = false;
            Boolean sal = false;
            Boolean dl = false;
            Boolean ad = false;
            Boolean pc = false;
            c = client.getEmployeeByID(EmployeeID.Text.Trim());
            if (c.employeeID == null || c.employeeID == "")
            {
                if (Firstname.Text == null || Firstname.Text == "")
                {
                    Response.Write("Firstname cannot be blank !");
                }
                else
                {

                    cIdResult.firstName = Firstname.Text;
                    fname = true;
                }
                if (LastName.Text == null || LastName.Text == "")
                {
                    Response.Write("Lastname cannot be blank !");
                }
                else
                {
                    cIdResult.lastName = LastName.Text;
                    lname = true;
                }

                if (EmployeeID.Text == null || EmployeeID.Text == "")
                {
                    Response.Write("EmployeeID cannot be blank !");
                }
                else
                {
                    cIdResult.employeeID = EmployeeID.Text;
                    eId = true;
                }

                if (Email.Text == null || Email.Text == "")
                {
                    Response.Write("Email cannot be blank !");
                }
                else
                {
                    cIdResult.email = Email.Text;
                    mail = true;
                }

                cIdResult.extension = Extension.Text;

                cIdResult.homePhone = HomePhone.Text;

                if (CellPhone.Text == null || CellPhone.Text == "")
                {
                    Response.Write("CellPhone cannot be blank !");
                }
                else
                {
                    cIdResult.cellPhone = CellPhone.Text;
                    cPhone = true;
                }
                if (JobTitle.Text == null || JobTitle.Text == "")
                {
                    Response.Write("JobTitle cannot be blank !");
                }
                else
                {
                    cIdResult.jobTitle = JobTitle.Text;
                    title = true;
                }

                if (SocialSecurityNumber.Text == null || SocialSecurityNumber.Text == "")
                {
                    Response.Write("SocialSecurityNumber cannot be blank !");
                }
                else
                {
                    cIdResult.socialSecurityNumber = SocialSecurityNumber.Text;
                    ssn = true;
                }

                if (Salary.Text == null || Salary.Text == "")
                {
                    Response.Write("Salary cannot be blank !");
                }
                else
                {
                    cIdResult.salary = Convert.ToDouble("25000");
                    sal = true;
                }
                if (Salary.Text == null || Salary.Text == "")
                {
                    Response.Write("Salary cannot be blank !");
                }
                else
                {
                    cIdResult.salary = Convert.ToDouble("25000");
                    sal = true;
                }
                if (DriverLicenseNumber.Text == null || DriverLicenseNumber.Text == "")
                {
                    Response.Write("DriverLicenseNumber cannot be blank !");
                }
                else
                {
                    cIdResult.driverLicenseNumber = DriverLicenseNumber.Text;
                    dl = true;
                }
                if (AddressLine1.Text == null || AddressLine1.Text == "")
                {
                    Response.Write("AddressLine1 cannot be blank !");
                }
                else
                {
                    cIdResult.addressLine1 = AddressLine1.Text;
                    ad = true;
                }
                cIdResult.addressLine2 = AddressLine2.Text;
                cIdResult.city = City.Text;
                cIdResult.state = State.Text;
                if (PostalCode.Text == null || PostalCode.Text == "")
                {
                    Response.Write("PostalCode cannot be blank !");
                }
                else
                {
                    cIdResult.postalCode = Convert.ToInt32(PostalCode.Text);
                    pc = true;
                }

                cIdResult.notes = Notes.Text;

                if (fname && lname && eId && mail && cPhone && title && ssn && sal && dl && ad && pc)
                {
                    Boolean result = client.createEmployee(cIdResult);
                    if (result)
                    {
                        Response.Write("Employee created successfully. Click Cancel to get back");
                    }
                    else
                    {
                        Response.Write("Employee creation failed. Contact System Admin");
                    }
                }
            }
            else
            {
                Response.Write("Employee ID exists !! Use different id");
            }
            
           
        }

        protected void Cancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminEmployeeMgmtPage.aspx");
        }
    }
}