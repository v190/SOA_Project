﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TruckWebApp.Admin
{
    public partial class UpdateEmployee : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Submit_Click(object sender, EventArgs e)
        {
            TruckWebServiceReference.TruckCatalogClient client = new TruckWebServiceReference.TruckCatalogClient();
            TruckWebServiceReference.employee cIdResult = new TruckWebServiceReference.employee();
            cIdResult.employeeID = EmployeeID.Text;
            cIdResult.firstName = Firstname.Text;
            cIdResult.lastName = LastName.Text;
            cIdResult.email = Email.Text;
            cIdResult.extension = Extension.Text;
            cIdResult.homePhone = HomePhone.Text;
            cIdResult.cellPhone = CellPhone.Text;
            cIdResult.jobTitle = JobTitle.Text;
            cIdResult.socialSecurityNumber = SocialSecurityNumber.Text;
            cIdResult.salary = Convert.ToDouble(Salary.Text);
            cIdResult.driverLicenseNumber = DriverLicenseNumber.Text;
            cIdResult.addressLine1 = AddressLine1.Text;
            cIdResult.addressLine2 = AddressLine2.Text;
            cIdResult.city = City.Text;
            cIdResult.state = State.Text;
            cIdResult.postalCode = Convert.ToInt32(PostalCode.Text);
            cIdResult.notes = Notes.Text;

            Boolean result = client.updateEmployee(cIdResult);

            if (result)
            {
                Response.Write("Employee updates successfully.. Click Cancel to go back");
            }
            else
            {
                Response.Write("Failed.. Contact System Admin");
            }

        }

        protected void Cancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminEmployeeMgmtPage.aspx");
        }

        protected void search_Click(object sender, EventArgs e)
        {
            TruckWebServiceReference.TruckCatalogClient client = new TruckWebServiceReference.TruckCatalogClient();
            TruckWebServiceReference.employee cIdResult = new TruckWebServiceReference.employee();
            if(eid.Text==null && eid.Text == "")
            {
                Response.Write("Enter the valid Employee ID");
            }
            else
            {
                cIdResult=client.getEmployeeByID(eid.Text);
                if(cIdResult.employeeID==null && cIdResult.firstName == "")
                {
                    Response.Write("No employee found with the ID");
                }
                else
                {
                    EmployeeID.Text = cIdResult.employeeID;
                    Firstname.Text = cIdResult.firstName;
                    LastName.Text = cIdResult.lastName;
                    Email.Text = cIdResult.email;
                    Extension.Text = cIdResult.extension;
                    HomePhone.Text = cIdResult.homePhone;
                    CellPhone.Text = cIdResult.homePhone;
                    JobTitle.Text = cIdResult.jobTitle;
                    SocialSecurityNumber.Text = cIdResult.socialSecurityNumber;
                    Salary.Text = cIdResult.salary.ToString();
                    DriverLicenseNumber.Text = cIdResult.driverLicenseNumber;
                    AddressLine1.Text = cIdResult.addressLine1;
                    AddressLine2.Text = cIdResult.addressLine2;
                    City.Text = cIdResult.city;
                    State.Text = cIdResult.state;
                    PostalCode.Text = cIdResult.postalCode.ToString();
                    Notes.Text = cIdResult.notes;

                }
            }
            
        }
    }
}