﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TruckWebApp.Admin
{
    public partial class AdminEmployeeMgmtPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void add_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddEmployee.aspx");
        }


        protected void CustomView_Click(object sender, EventArgs e)
        {
            Response.Redirect("UpdateEmployee.aspx");
        }

        protected void allEmployees_Click(object sender, EventArgs e)
        {
            TruckWebServiceReference.TruckCatalogClient client = new TruckWebServiceReference.TruckCatalogClient();
            var list = client.getAllEmployee();
            if (list == null)
            {
                Response.Write("No results for the given values");
            }
            else
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("EmployeeID");
                dt.Columns.Add("FirstName");
                dt.Columns.Add("LastName");
                dt.Columns.Add("Email");
                dt.Columns.Add("Extension");
                dt.Columns.Add("HomePhone");
                dt.Columns.Add("CellPhone");
                dt.Columns.Add("JobTitle");
                dt.Columns.Add("SocialSecurityNumber");
                dt.Columns.Add("DateHired");
                dt.Columns.Add("Salary");
                dt.Columns.Add("DriverLicenseNumber");
                dt.Columns.Add("AddressLine1");
                dt.Columns.Add("AddressLine2");
                dt.Columns.Add("City");
                dt.Columns.Add("State");
                dt.Columns.Add("PostalCode");
                dt.Columns.Add("Birthdate");
                dt.Columns.Add("Notes");

                for (int i = 0; i < list.Count(); i++)
                {
                    dt.Rows.Add();
                    dt.Rows[i]["EmployeeID"] = list[i].employeeID;
                    dt.Rows[i]["FirstName"] = list[i].firstName;
                    dt.Rows[i]["LastName"] = list[i].lastName;
                    dt.Rows[i]["Email"] = list[i].email;
                    dt.Rows[i]["Extension"] = list[i].extension;
                    dt.Rows[i]["HomePhone"] = list[i].homePhone;
                    dt.Rows[i]["CellPhone"] = list[i].cellPhone;
                    dt.Rows[i]["JobTitle"] = list[i].jobTitle;
                    dt.Rows[i]["SocialSecurityNumber"] = list[i].socialSecurityNumber;
                    dt.Rows[i]["DateHired"] = list[i].dateHired;
                    dt.Rows[i]["Salary"] = list[i].salary;
                    dt.Rows[i]["DriverLicenseNumber"] = list[i].driverLicenseNumber;
                    dt.Rows[i]["AddressLine1"] = list[i].addressLine1;
                    dt.Rows[i]["AddressLine2"] = list[i].addressLine2;
                    dt.Rows[i]["City"] = list[i].city;
                    dt.Rows[i]["State"] = list[i].state;
                    dt.Rows[i]["PostalCode"] = list[i].postalCode;
                    dt.Rows[i]["Birthdate"] = list[i].birthdate;
                    dt.Rows[i]["Notes"] = list[i].notes;

                }
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
        }

        protected void Delete_Click(object sender, EventArgs e)
        {
            Response.Redirect("DeleteEmployee.aspx");
        }

        protected void homeBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminLandingPage.aspx");
        }
    }
}