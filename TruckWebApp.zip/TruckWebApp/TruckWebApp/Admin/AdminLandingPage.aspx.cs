﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TruckWebApp.Admin
{
    public partial class AdminLandingPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void CustomersLinkBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminCustomerMgmtPage.aspx");
        }

        protected void EmployeesLinkBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminEmployeeMgmtPage.aspx");
        }

        protected void OrdersLinkBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("OtherServicesPage.aspx");
        }

        protected void logoutBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("/logout.aspx");
        }
    }
}