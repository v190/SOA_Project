/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.itm566.jaxws;

import java.util.logging.Logger;

/**
 *
 * @author varsh
 */
public class Location {
    private String LocationID;
    private String CustomerID;
    private String LocName;
    private String LocationCode;
    private boolean IsAuction;
    private String AddressStreet1;
    private String AddressStreet2;
    private String City;
    private String State;
    private int PostalCode;
    private String Region;
    private String LocationContactName;
    private String LocPhone;
    private String LocFaxNumber;
    private String LocEmail;
    
    private static final Logger LOG = Logger.getLogger(Location.class.getName());

    public Location() {
    }

    public Location(String LocationID, String CustomerID, String LocName, String LocationCode, boolean IsAuction, String AddressStreet1, String AddressStreet2, String City, String State, int PostalCode, String Region, String LocationContactName, String LocPhone, String LocFaxNumber, String LocEmail) {
        this.LocationID = LocationID;
        this.CustomerID = CustomerID;
        this.LocName = LocName;
        this.LocationCode = LocationCode;
        this.IsAuction = IsAuction;
        this.AddressStreet1 = AddressStreet1;
        this.AddressStreet2 = AddressStreet2;
        this.City = City;
        this.State = State;
        this.PostalCode = PostalCode;
        this.Region = Region;
        this.LocationContactName = LocationContactName;
        this.LocPhone = LocPhone;
        this.LocFaxNumber = LocFaxNumber;
        this.LocEmail = LocEmail;
    }

    public String getLocationID() {
        return LocationID;
    }

    public void setLocationID(String LocationID) {
        this.LocationID = LocationID;
    }

    public String getCustomerID() {
        return CustomerID;
    }

    public void setCustomerID(String CustomerID) {
        this.CustomerID = CustomerID;
    }

    public String getLocName() {
        return LocName;
    }

    public void setLocName(String LocName) {
        this.LocName = LocName;
    }

    public String getLocationCode() {
        return LocationCode;
    }

    public void setLocationCode(String LocationCode) {
        this.LocationCode = LocationCode;
    }

    public boolean isIsAuction() {
        return IsAuction;
    }

    public void setIsAuction(boolean IsAuction) {
        this.IsAuction = IsAuction;
    }

    public String getAddressStreet1() {
        return AddressStreet1;
    }

    public void setAddressStreet1(String AddressStreet1) {
        this.AddressStreet1 = AddressStreet1;
    }

    public String getAddressStreet2() {
        return AddressStreet2;
    }

    public void setAddressStreet2(String AddressStreet2) {
        this.AddressStreet2 = AddressStreet2;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String City) {
        this.City = City;
    }

    public String getState() {
        return State;
    }

    public void setState(String State) {
        this.State = State;
    }

    public int getPostalCode() {
        return PostalCode;
    }

    public void setPostalCode(int PostalCode) {
        this.PostalCode = PostalCode;
    }

    public String getRegion() {
        return Region;
    }

    public void setRegion(String Region) {
        this.Region = Region;
    }

    public String getLocationContactName() {
        return LocationContactName;
    }

    public void setLocationContactName(String LocationContactName) {
        this.LocationContactName = LocationContactName;
    }

    public String getLocPhone() {
        return LocPhone;
    }

    public void setLocPhone(String LocPhone) {
        this.LocPhone = LocPhone;
    }

    public String getLocFaxNumber() {
        return LocFaxNumber;
    }

    public void setLocFaxNumber(String LocFaxNumber) {
        this.LocFaxNumber = LocFaxNumber;
    }

    public String getLocEmail() {
        return LocEmail;
    }

    public void setLocEmail(String LocEmail) {
        this.LocEmail = LocEmail;
    }

    @Override
    public String toString() {
        return "Location{" + "LocationID=" + LocationID + ", CustomerID=" + CustomerID + ", LocName=" + LocName + ", LocationCode=" + LocationCode + ", IsAuction=" + IsAuction + ", AddressStreet1=" + AddressStreet1 + ", AddressStreet2=" + AddressStreet2 + ", City=" + City + ", State=" + State + ", PostalCode=" + PostalCode + ", Region=" + Region + ", LocationContactName=" + LocationContactName + ", LocPhone=" + LocPhone + ", LocFaxNumber=" + LocFaxNumber + ", LocEmail=" + LocEmail + '}';
    }
    
    
}
