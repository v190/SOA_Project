/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.itm566.jaxws;

import java.sql.Date;
import java.util.logging.Logger;

/**
 *
 * @author varsh
 */
public class Expenses{
    private String ExpenseID;
    private String EmployeeID;
    private String ExpenseType;
    private String PurposeofExpense;
    private Double AmountSpent;
    private String Description;
    private Date DatePurchased;
    private Date DateSubmitted;
    private Double AdvanceAmount;
    private String PaymentMethod;

    private static final Logger LOG = Logger.getLogger(Expenses.class.getName());

    public Expenses() {
    }

    public String getExpenseID() {
        return ExpenseID;
    }

    public void setExpenseID(String ExpenseID) {
        this.ExpenseID = ExpenseID;
    }

    public String getEmployeeID() {
        return EmployeeID;
    }

    public void setEmployeeID(String EmployeeID) {
        this.EmployeeID = EmployeeID;
    }

    public String getExpenseType() {
        return ExpenseType;
    }

    public void setExpenseType(String ExpenseType) {
        this.ExpenseType = ExpenseType;
    }

    public String getPurposeofExpense() {
        return PurposeofExpense;
    }

    public void setPurposeofExpense(String PurposeofExpense) {
        this.PurposeofExpense = PurposeofExpense;
    }

    public Double getAmountSpent() {
        return AmountSpent;
    }

    public void setAmountSpent(Double AmountSpent) {
        this.AmountSpent = AmountSpent;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public Date getDatePurchased() {
        return DatePurchased;
    }

    public void setDatePurchased(Date DatePurchased) {
        this.DatePurchased = DatePurchased;
    }

    public Date getDateSubmitted() {
        return DateSubmitted;
    }

    public void setDateSubmitted(Date DateSubmitted) {
        this.DateSubmitted = DateSubmitted;
    }

    public Double getAdvanceAmount() {
        return AdvanceAmount;
    }

    public void setAdvanceAmount(Double AdvanceAmount) {
        this.AdvanceAmount = AdvanceAmount;
    }

    public String getPaymentMethod() {
        return PaymentMethod;
    }

    public void setPaymentMethod(String PaymentMethod) {
        this.PaymentMethod = PaymentMethod;
    }

    @Override
    public String toString() {
        return "Expenses{" + "ExpenseID=" + ExpenseID + ", EmployeeID=" + EmployeeID + ", ExpenseType=" + ExpenseType + ", PurposeofExpense=" + PurposeofExpense + ", AmountSpent=" + AmountSpent + ", Description=" + Description + ", DatePurchased=" + DatePurchased + ", DateSubmitted=" + DateSubmitted + ", AdvanceAmount=" + AdvanceAmount + ", PaymentMethod=" + PaymentMethod + '}';
    }
}
