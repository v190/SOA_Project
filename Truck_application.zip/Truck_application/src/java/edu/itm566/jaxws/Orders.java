/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.itm566.jaxws;

import java.sql.Date;
import java.util.logging.Logger;

/**
 *
 * @author varsh
 */
public class Orders{
    private String OrderID;
    private Date OrderDate;
    private String CustomerID;
    private String EmployeeID;
    private String TruckID;
    private Boolean IsSpecial;
    private int PurchaseOrderNumber;
    private Double OrderTotalAmount;

    private static final Logger LOG = Logger.getLogger(Orders.class.getName());

    public Orders() {
    }

    public String getOrderID() {
        return OrderID;
    }

    public void setOrderID(String OrderID) {
        this.OrderID = OrderID;
    }

    public Date getOrderDate() {
        return OrderDate;
    }

    public void setOrderDate(Date OrderDate) {
        this.OrderDate = OrderDate;
    }

    public String getCustomerID() {
        return CustomerID;
    }

    public void setCustomerID(String CustomerID) {
        this.CustomerID = CustomerID;
    }

    public String getEmployeeID() {
        return EmployeeID;
    }

    public void setEmployeeID(String EmployeeID) {
        this.EmployeeID = EmployeeID;
    }

    public String getTruckID() {
        return TruckID;
    }

    public void setTruckID(String TruckID) {
        this.TruckID = TruckID;
    }

    public Boolean getIsSpecial() {
        return IsSpecial;
    }

    public void setIsSpecial(Boolean IsSpecial) {
        this.IsSpecial = IsSpecial;
    }

    public int getPurchaseOrderNumber() {
        return PurchaseOrderNumber;
    }

    public void setPurchaseOrderNumber(int PurchaseOrderNumber) {
        this.PurchaseOrderNumber = PurchaseOrderNumber;
    }

    public Double getOrderTotalAmount() {
        return OrderTotalAmount;
    }

    public void setOrderTotalAmount(Double OrderTotalAmount) {
        this.OrderTotalAmount = OrderTotalAmount;
    }

    @Override
    public String toString() {
        return "Orders{" + "OrderID=" + OrderID + ", OrderDate=" + OrderDate + ", CustomerID=" + CustomerID + ", EmployeeID=" + EmployeeID + ", TruckID=" + TruckID + ", IsSpecial=" + IsSpecial + ", PurchaseOrderNumber=" + PurchaseOrderNumber + ", OrderTotalAmount=" + OrderTotalAmount + '}';
    }
}
