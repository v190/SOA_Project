/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.itm566.jaxws;

import java.sql.Time;
import java.util.logging.Logger;

/**
 *
 * @author varsh
 */
public class Comments{
    private String CommentID;
    private String CustomerID;
    private String LocationID;
    private String TransactionID;
    private Time CommentTime;
    private String CommentLine;

    private static final Logger LOG = Logger.getLogger(Comments.class.getName());

    public Comments() {
    }

    public String getCommentID() {
        return CommentID;
    }

    public void setCommentID(String CommentID) {
        this.CommentID = CommentID;
    }

    public String getCustomerID() {
        return CustomerID;
    }

    public void setCustomerID(String CustomerID) {
        this.CustomerID = CustomerID;
    }

    public String getLocationID() {
        return LocationID;
    }

    public void setLocationID(String LocationID) {
        this.LocationID = LocationID;
    }

    public String getTransactionID() {
        return TransactionID;
    }

    public void setTransactionID(String TransactionID) {
        this.TransactionID = TransactionID;
    }

    public Time getCommentTime() {
        return CommentTime;
    }

    public void setCommentTime(Time CommentTime) {
        this.CommentTime = CommentTime;
    }

    public String getCommentLine() {
        return CommentLine;
    }

    public void setCommentLine(String CommentLine) {
        this.CommentLine = CommentLine;
    }

    @Override
    public String toString() {
        return "Comments{" + "CommentID=" + CommentID + ", CustomerID=" + CustomerID + ", LocationID=" + LocationID + ", TransactionID=" + TransactionID + ", CommentTime=" + CommentTime + ", CommentLine=" + CommentLine + '}';
    }

    
}
