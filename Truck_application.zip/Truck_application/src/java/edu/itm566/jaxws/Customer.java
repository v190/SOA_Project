/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.itm566.jaxws;

import java.sql.Date;
import java.util.logging.Logger;

/**
 *
 * @author varsh
 */
public class Customer {
    private String CustomerID;
    private String Title;
    private String BusinessName;
    private String Address;
    private String City;
    private String State;
    private int PostalCode;
    private String Country;
    private String PhoneNumber;
    private String CellNumber;
    private String OtherNumber;
    private String FaxNumber;
    private String EmailAddress;
    private String Type;
    private String Name;
    private String ContactName;
    private String AlternateContactName;
    private Date DateEntered;
    private static final Logger LOG = Logger.getLogger(Customer.class.getName());

    public Customer() {
    }
    
    

    public Customer(String CustomerID, String Title, String BusinessName, String Address, String City, String State, int PostalCode, String Country, String PhoneNumber, String CellNumber, String OtherNumber, String FaxNumber, String EmailAddress, String Type, String Name, String ContactName, String AlternateContactName, Date DateEntered) {
        this.CustomerID = CustomerID;
        this.Title = Title;
        this.BusinessName = BusinessName;
        this.Address = Address;
        this.City = City;
        this.State = State;
        this.PostalCode = PostalCode;
        this.Country = Country;
        this.PhoneNumber = PhoneNumber;
        this.CellNumber = CellNumber;
        this.OtherNumber = OtherNumber;
        this.FaxNumber = FaxNumber;
        this.EmailAddress = EmailAddress;
        this.Type = Type;
        this.Name = Name;
        this.ContactName = ContactName;
        this.AlternateContactName = AlternateContactName;
        this.DateEntered = DateEntered;
    }

    public String getCustomerID() {
        return CustomerID;
    }

    public void setCustomerID(String CustomerID) {
        this.CustomerID = CustomerID;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String Title) {
        this.Title = Title;
    }

    public String getBusinessName() {
        return BusinessName;
    }

    public void setBusinessName(String BusinessName) {
        this.BusinessName = BusinessName;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String City) {
        this.City = City;
    }

    public String getState() {
        return State;
    }

    public void setState(String State) {
        this.State = State;
    }

    public int getPostalCode() {
        return PostalCode;
    }

    public void setPostalCode(int PostalCode) {
        this.PostalCode = PostalCode;
    }

    public String getCountry() {
        return Country;
    }

    public void setCountry(String Country) {
        this.Country = Country;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String PhoneNumber) {
        this.PhoneNumber = PhoneNumber;
    }

    public String getCellNumber() {
        return CellNumber;
    }

    public void setCellNumber(String CellNumber) {
        this.CellNumber = CellNumber;
    }

    public String getOtherNumber() {
        return OtherNumber;
    }

    public void setOtherNumber(String OtherNumber) {
        this.OtherNumber = OtherNumber;
    }

    public String getFaxNumber() {
        return FaxNumber;
    }

    public void setFaxNumber(String FaxNumber) {
        this.FaxNumber = FaxNumber;
    }

    public String getEmailAddress() {
        return EmailAddress;
    }

    public void setEmailAddress(String EmailAddress) {
        this.EmailAddress = EmailAddress;
    }

    public String getType() {
        return Type;
    }

    public void setType(String Type) {
        this.Type = Type;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getContactName() {
        return ContactName;
    }

    public void setContactName(String ContactName) {
        this.ContactName = ContactName;
    }

    public String getAlternateContactName() {
        return AlternateContactName;
    }

    public void setAlternateContactName(String AlternateContactName) {
        this.AlternateContactName = AlternateContactName;
    }

    public Date getDateEntered() {
        return DateEntered;
    }

    public void setDateEntered(Date DateEntered) {
        this.DateEntered = DateEntered;
    }

    @Override
    public String toString() {
        return "Customer{" + "CustomerID=" + CustomerID + ", Title=" + Title + ", BusinessName=" + BusinessName + ", Address=" + Address + ", City=" + City + ", State=" + State + ", PostalCode=" + PostalCode + ", Country=" + Country + ", PhoneNumber=" + PhoneNumber + ", CellNumber=" + CellNumber + ", OtherNumber=" + OtherNumber + ", FaxNumber=" + FaxNumber + ", EmailAddress=" + EmailAddress + ", Type=" + Type + ", Name=" + Name + ", ContactName=" + ContactName + ", AlternateContactName=" + AlternateContactName + ", DateEntered=" + DateEntered + '}';
    }
    
    
}
