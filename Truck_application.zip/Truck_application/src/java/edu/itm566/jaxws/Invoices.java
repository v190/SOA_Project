/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.itm566.jaxws;

import java.util.logging.Logger;

/**
 *
 * @author varsh
 */
public class Invoices{
    private String InvoiceID;
    private String OrderID;
    private String EmployeeID;
    private String CustomerID;
    private String Description;
    private Double Price;
    private int Quantity;

    private static final Logger LOG = Logger.getLogger(Invoices.class.getName());

    public Invoices() {
    }

    public String getInvoiceID() {
        return InvoiceID;
    }

    public void setInvoiceID(String InvoiceID) {
        this.InvoiceID = InvoiceID;
    }

    public String getOrderID() {
        return OrderID;
    }

    public void setOrderID(String OrderID) {
        this.OrderID = OrderID;
    }

    public String getEmployeeID() {
        return EmployeeID;
    }

    public void setEmployeeID(String EmployeeID) {
        this.EmployeeID = EmployeeID;
    }

    public String getCustomerID() {
        return CustomerID;
    }

    public void setCustomerID(String CustomerID) {
        this.CustomerID = CustomerID;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public Double getPrice() {
        return Price;
    }

    public void setPrice(Double Price) {
        this.Price = Price;
    }

    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int Quantity) {
        this.Quantity = Quantity;
    }

    @Override
    public String toString() {
        return "Invoices{" + "InvoiceID=" + InvoiceID + ", OrderID=" + OrderID + ", EmployeeID=" + EmployeeID + ", CustomerID=" + CustomerID + ", Description=" + Description + ", Price=" + Price + ", Quantity=" + Quantity + '}';
    }
}
