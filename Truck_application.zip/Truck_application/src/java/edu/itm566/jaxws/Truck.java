/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.itm566.jaxws;

import java.util.logging.Logger;

/**
 *
 * @author varsh
 */
public class Truck {
    private String TruckNo;
    private String Make;
    private String Year;
    private String Model;
    private String LicensePlateNo;
    private String EmployeeID;
    private String Color;
    private String Vin;

    private static final Logger LOG = Logger.getLogger(Truck.class.getName());

    public Truck() {
    }

    public String getTruckNo() {
        return TruckNo;
    }

    public void setTruckNo(String TruckNo) {
        this.TruckNo = TruckNo;
    }

    public String getMake() {
        return Make;
    }

    public void setMake(String Make) {
        this.Make = Make;
    }

    public String getYear() {
        return Year;
    }

    public void setYear(String Year) {
        this.Year = Year;
    }

    public String getModel() {
        return Model;
    }

    public void setModel(String Model) {
        this.Model = Model;
    }

    public String getLicensePlateNo() {
        return LicensePlateNo;
    }

    public void setLicensePlateNo(String LicensePlateNo) {
        this.LicensePlateNo = LicensePlateNo;
    }

    public String getEmployeeID() {
        return EmployeeID;
    }

    public void setEmployeeID(String EmployeeID) {
        this.EmployeeID = EmployeeID;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String Color) {
        this.Color = Color;
    }

    public String getVin() {
        return Vin;
    }

    public void setVin(String Vin) {
        this.Vin = Vin;
    }

    @Override
    public String toString() {
        return "Truck{" + "TruckNo=" + TruckNo + ", Make=" + Make + ", Year=" + Year + ", Model=" + Model + ", LicensePlateNo=" + LicensePlateNo + ", EmployeeID=" + EmployeeID + ", Color=" + Color + ", Vin=" + Vin + '}';
    }
    
    
}
