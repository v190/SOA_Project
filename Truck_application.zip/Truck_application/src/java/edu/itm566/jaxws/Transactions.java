/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.itm566.jaxws;

import java.sql.Date;
import java.util.logging.Logger;

/**
 *
 * @author varsh
 */
public class Transactions{
    private String TransactionID;
    private String OrderID;
    private String PriceID;
    private Date TransactionDate;
    private String TransactionDescription;
    private Double TransactionAmount;
    private String make;
    private String year;
    private String EmployeeID;
    private String TruckNo;
    private Double discount;
    private int quantity;
    private Double unitPrice;
    private Double driverPrice;
    private String VIN;
    private int runNumber;
    private Boolean special;
    private Double rate;
    private Double Surcharge;

    private static final Logger LOG = Logger.getLogger(Transactions.class.getName());

    public Transactions() {
    }

    public String getTransactionID() {
        return TransactionID;
    }

    public void setTransactionID(String TransactionID) {
        this.TransactionID = TransactionID;
    }

    public String getOrderID() {
        return OrderID;
    }

    public void setOrderID(String OrderID) {
        this.OrderID = OrderID;
    }

    public String getPriceID() {
        return PriceID;
    }

    public void setPriceID(String PriceID) {
        this.PriceID = PriceID;
    }

    public Date getTransactionDate() {
        return TransactionDate;
    }

    public void setTransactionDate(Date TransactionDate) {
        this.TransactionDate = TransactionDate;
    }

    public String getTransactionDescription() {
        return TransactionDescription;
    }

    public void setTransactionDescription(String TransactionDescription) {
        this.TransactionDescription = TransactionDescription;
    }

    public Double getTransactionAmount() {
        return TransactionAmount;
    }

    public void setTransactionAmount(Double TransactionAmount) {
        this.TransactionAmount = TransactionAmount;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getEmployeeID() {
        return EmployeeID;
    }

    public void setEmployeeID(String EmployeeID) {
        this.EmployeeID = EmployeeID;
    }

    public String getTruckNo() {
        return TruckNo;
    }

    public void setTruckNo(String TruckNo) {
        this.TruckNo = TruckNo;
    }

    public Double getDiscount() {
        return discount;
    }

    public void setDiscount(Double discount) {
        this.discount = discount;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(Double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public Double getDriverPrice() {
        return driverPrice;
    }

    public void setDriverPrice(Double driverPrice) {
        this.driverPrice = driverPrice;
    }

    public String getVIN() {
        return VIN;
    }

    public void setVIN(String VIN) {
        this.VIN = VIN;
    }

    public int getRunNumber() {
        return runNumber;
    }

    public void setRunNumber(int runNumber) {
        this.runNumber = runNumber;
    }

    public Boolean getSpecial() {
        return special;
    }

    public void setSpecial(Boolean special) {
        this.special = special;
    }

    public Double getRate() {
        return rate;
    }

    public void setRate(Double rate) {
        this.rate = rate;
    }

    public Double getSurcharge() {
        return Surcharge;
    }

    public void setSurcharge(Double Surcharge) {
        this.Surcharge = Surcharge;
    }

    @Override
    public String toString() {
        return "Transactions{" + "TransactionID=" + TransactionID + ", OrderID=" + OrderID + ", PriceID=" + PriceID + ", TransactionDate=" + TransactionDate + ", TransactionDescription=" + TransactionDescription + ", TransactionAmount=" + TransactionAmount + ", make=" + make + ", year=" + year + ", EmployeeID=" + EmployeeID + ", TruckNo=" + TruckNo + ", discount=" + discount + ", quantity=" + quantity + ", unitPrice=" + unitPrice + ", driverPrice=" + driverPrice + ", VIN=" + VIN + ", runNumber=" + runNumber + ", special=" + special + ", rate=" + rate + ", Surcharge=" + Surcharge + '}';
    }
   
    
}
