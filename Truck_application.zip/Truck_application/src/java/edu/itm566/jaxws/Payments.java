/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.itm566.jaxws;

import java.sql.Date;
import java.util.logging.Logger;

/**
 *
 * @author varsh
 */
public class Payments{
    private String PaymentID;
    private String OrderID;
    private String PaymentMethodID;
    private Double PaymentAmount;
    private Date PaymentDate;
    private String CheckNumber;
    private String CreditCard;
    private String CreditCardNumber;
    private String CreditCardHoldersName;
    private String CreditCardExpDate;
    private int CreditCardAuthorizedName;

    private static final Logger LOG = Logger.getLogger(Payments.class.getName());

    public Payments() {
    }  

    public String getPaymentID() {
        return PaymentID;
    }

    public void setPaymentID(String PaymentID) {
        this.PaymentID = PaymentID;
    }

    public String getOrderID() {
        return OrderID;
    }

    public void setOrderID(String OrderID) {
        this.OrderID = OrderID;
    }

    public String getPaymentMethodID() {
        return PaymentMethodID;
    }

    public void setPaymentMethodID(String PaymentMethodID) {
        this.PaymentMethodID = PaymentMethodID;
    }

    public Double getPaymentAmount() {
        return PaymentAmount;
    }

    public void setPaymentAmount(Double PaymentAmount) {
        this.PaymentAmount = PaymentAmount;
    }

    public Date getPaymentDate() {
        return PaymentDate;
    }

    public void setPaymentDate(Date PaymentDate) {
        this.PaymentDate = PaymentDate;
    }

    public String getCheckNumber() {
        return CheckNumber;
    }

    public void setCheckNumber(String CheckNumber) {
        this.CheckNumber = CheckNumber;
    }

    public String getCreditCard() {
        return CreditCard;
    }

    public void setCreditCard(String CreditCard) {
        this.CreditCard = CreditCard;
    }

    public String getCreditCardNumber() {
        return CreditCardNumber;
    }

    public void setCreditCardNumber(String CreditCardNumber) {
        this.CreditCardNumber = CreditCardNumber;
    }

    public String getCreditCardHoldersName() {
        return CreditCardHoldersName;
    }

    public void setCreditCardHoldersName(String CreditCardHoldersName) {
        this.CreditCardHoldersName = CreditCardHoldersName;
    }

    public String getCreditCardExpDate() {
        return CreditCardExpDate;
    }

    public void setCreditCardExpDate(String CreditCardExpDate) {
        this.CreditCardExpDate = CreditCardExpDate;
    }

    public int getCreditCardAuthorizedName() {
        return CreditCardAuthorizedName;
    }

    public void setCreditCardAuthorizedName(int CreditCardAuthorizedName) {
        this.CreditCardAuthorizedName = CreditCardAuthorizedName;
    }

    @Override
    public String toString() {
        return "Payments{" + "PaymentID=" + PaymentID + ", OrderID=" + OrderID + ", PaymentMethodID=" + PaymentMethodID + ", PaymentAmount=" + PaymentAmount + ", PaymentDate=" + PaymentDate + ", CheckNumber=" + CheckNumber + ", CreditCard=" + CreditCard + ", CreditCardNumber=" + CreditCardNumber + ", CreditCardHoldersName=" + CreditCardHoldersName + ", CreditCardExpDate=" + CreditCardExpDate + ", CreditCardAuthorizedName=" + CreditCardAuthorizedName + '}';
    }
    
    
}
