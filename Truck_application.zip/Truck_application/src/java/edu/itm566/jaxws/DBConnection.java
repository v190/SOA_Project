/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.itm566.jaxws;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author varsh
 */
public class DBConnection {

    public DBConnection() {
    }

    public Connection getDbConnection() throws SQLException {
        String username = "root";
        String password = "root";
        Connection con = null;
        String url = "jdbc:mysql://localhost:3306/soa?useSSL=false";
        System.out.println("Get DB Connection");
        con = DriverManager.getConnection(url, username, password);
        return con;
    }
}
