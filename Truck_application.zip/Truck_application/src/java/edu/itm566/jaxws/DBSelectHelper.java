/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.itm566.jaxws;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

/**
 *
 * @author varsh
 */
public class DBSelectHelper {

    private static final Logger LOG = Logger.getLogger(DBSelectHelper.class.getName());

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    public DBSelectHelper() {
    }

    public Customer getCustomerByID(String cID, Statement st) {
        Customer c = new Customer();
        try {

            ResultSet rs = st.executeQuery("select * from customers where customerID= '" + cID + "'");
            while (rs.next()) {
                c.setCustomerID(rs.getString("CustomerID"));
                c.setTitle(rs.getString("Title"));
                c.setBusinessName(rs.getString("BusinessName"));
                c.setAddress(rs.getString("Address"));
                c.setCity(rs.getString("City"));
                c.setState(rs.getString("State"));
                c.setPostalCode(rs.getInt("PostalCode"));
                c.setCountry(rs.getString("Country"));
                c.setPhoneNumber(rs.getString("PhoneNumber"));
                c.setCellNumber(rs.getString("CellNumber"));
                c.setOtherNumber(rs.getString("OtherNumber"));
                c.setFaxNumber(rs.getString("FaxNumber"));
                c.setEmailAddress(rs.getString("EmailAddress"));
                c.setType(rs.getString("Type"));
                c.setName(rs.getString("CompanyName"));
                c.setContactName(rs.getString("ContactName"));
                c.setAlternateContactName(rs.getString("AlternateContactName"));
                c.setDateEntered(rs.getDate("DateEntered"));
            }
            // LOG.info("test.Test.main()" + c.toString());
        } catch (Exception e) {
            LOG.info("Error in getCustomerID" + e.getMessage());
        }
        return c;
    }

    public List<Customer> getAllCustomers(Statement st) {
        
        ArrayList<Customer> cList = new ArrayList<>();
        try {

            ResultSet rs = st.executeQuery("select * from soa.customers");
            while (rs.next()) {
                Customer c = new Customer();
                c.setCustomerID(rs.getString("CustomerID"));
                c.setTitle(rs.getString("Title"));
                c.setBusinessName(rs.getString("BusinessName"));
                c.setAddress(rs.getString("Address"));
                c.setCity(rs.getString("City"));
                c.setState(rs.getString("State"));
                c.setPostalCode(rs.getInt("PostalCode"));
                c.setCountry(rs.getString("Country"));
                c.setPhoneNumber(rs.getString("PhoneNumber"));
                c.setCellNumber(rs.getString("CellNumber"));
                c.setOtherNumber(rs.getString("OtherNumber"));
                c.setFaxNumber(rs.getString("FaxNumber"));
                c.setEmailAddress(rs.getString("EmailAddress"));
                c.setType(rs.getString("Type"));
                c.setName(rs.getString("CompanyName"));
                c.setContactName(rs.getString("ContactName"));
                c.setAlternateContactName(rs.getString("AlternateContactName"));
                c.setDateEntered(rs.getDate("DateEntered"));

                cList.add(c);
            }
            for(int i =0; i<cList.size();i++){
                LOG.info(cList.get(i).toString());
            }
            // LOG.info("test.Test.main()" + c.toString());
        } catch (Exception e) {
            LOG.info("Error in getAllCustomers" + e.getMessage());
        }
        return cList;

    }

    public Boolean createCustomer(Customer c, Connection con) {
        Boolean result = false;
        try {

            PreparedStatement stmt = con.prepareStatement("insert into Customers values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            stmt.setString(1, c.getCustomerID());
            stmt.setString(2, c.getTitle());
            stmt.setString(3, c.getBusinessName());
            stmt.setString(4, c.getAddress());
            stmt.setString(5, c.getCity());
            stmt.setString(6, c.getState());
            stmt.setInt(7, c.getPostalCode());
            stmt.setString(8, c.getCountry());
            stmt.setString(9, c.getPhoneNumber());
            stmt.setString(10, c.getCellNumber());
            stmt.setString(11, c.getOtherNumber());
            stmt.setString(12, c.getFaxNumber());
            stmt.setString(13, c.getEmailAddress());
            stmt.setString(14, c.getType());
            stmt.setString(15, c.getName());
            stmt.setString(16, c.getContactName());
            stmt.setString(17, c.getAlternateContactName());
            stmt.setDate(18, c.getDateEntered());

            int i = stmt.executeUpdate();
            if (i == 1) {
                result=true;
                LOG.info("Customer created successfully");
            } else {
                result=false;
                LOG.info("Create customer failed");
            }
            stmt.close();
        } catch (Exception e) {
            result=false;
            LOG.info("Error while creating customer");
            LOG.info("Error in create Customer" + e.getMessage());
        }
        return result;
    }

    public Boolean deleteCustomer(String c, Connection con) {
      //  String result = "";
      Boolean result=false;
        try {

            PreparedStatement stmt = con.prepareStatement("delete from Customers where CustomerID=?");
            stmt.setString(1, c);

            int i = stmt.executeUpdate();
            if (i == 1) {
                LOG.info("Data deleted successfully");
                result=true;
            } else {
                LOG.info("Data deletion failed");
                result=false;
            }
            stmt.close();
        } catch (Exception e) {
            LOG.info("Error while inserting data");
            result=false;
            LOG.info("Error in delete Customer" + e.getMessage());
        }

        return result;
    }

    public String updateCustomer(Customer c, Statement st) {
        String result = "";
        LOG.info(c.toString());
        LOG.info("@@@@@@@@@@@@@@@@@");
        LOG.info("*****************8");
        try {
            String sql1 = "UPDATE soa.Customers set";
            if (c.getTitle() != null) {
                sql1 = sql1 + " title='" + c.getTitle() + "'";
            }
            if (c.getBusinessName() != null) {
                sql1 = sql1 + ",businessname='" + c.getBusinessName() + "'";
            }
            if (c.getAddress() != null) {
                sql1 = sql1 + ",address='" + c.getAddress() + "'";
            }
            if (c.getCity() != null) {
                sql1 = sql1 + ",city='" + c.getCity() + "'";
            }
            if (c.getState() != null) {
                sql1 = sql1 + ",state='" + c.getState() + "'";
            }
            if (c.getPostalCode() != 0) {
                sql1 = sql1 + ",PostalCode=" + c.getPostalCode();
            }
            if (c.getCountry() != null) {
                sql1 = sql1 + ",Country='" + c.getCountry() + "'";
            }
            if (c.getPhoneNumber() != null) {
                sql1 = sql1 + ",PhoneNumber='" + c.getPhoneNumber() + "'";
            }
            if (c.getCellNumber() != null) {
                sql1 = sql1 + ",CellNumber='" + c.getCellNumber() + "'";
            }
            if (c.getOtherNumber() != null) {
                sql1 = sql1 + ",OtherNumber='" + c.getOtherNumber() + "'";
            }
            if (c.getFaxNumber() != null) {
                sql1 = sql1 + ",FaxNumber='" + c.getFaxNumber() + "'";
            }
            if (c.getEmailAddress() != null) {
                sql1 = sql1 + ",EmailAddress='" + c.getEmailAddress() + "'";
            }
            if (c.getType() != null) {
                sql1 = sql1 + ",Type='" + c.getType() + "'";
            }
            if (c.getName() != null) {
                sql1 = sql1 + ",Name='" + c.getName() + "'";
            }
            if (c.getContactName() != null) {
                sql1 = sql1 + ",ContactName='" + c.getContactName() + "'";
            }
            if (c.getAlternateContactName() != null) {
                sql1 = sql1 + ",AlternateContactName='" + c.getAlternateContactName() + "'";
            }
            if (c.getDateEntered() != null) {
                sql1 = sql1 + ",DateEntered='" + c.getDateEntered() + "'";
            }
            sql1 = sql1 + " where CustomerID='" + c.getCustomerID() + "'";

            LOG.info("***************************************");
            LOG.info(sql1);
            st.executeUpdate(sql1);
            result = "Data updated successfully";
        } catch (Exception e) {
            result = "Error while inserting data";
            LOG.info("Error in Update Customer" + e.getMessage());
        }
        return result;
    }

    public List<Orders> getCustomerOrders(String c, Connection con) {
      //  String result = "";
      List<Orders> result= new ArrayList<Orders>();
      Orders e = new Orders();
        try {

            PreparedStatement stmt = con.prepareStatement("select * from soa.Orders where CustomerID=?");
            stmt.setString(1, c);

            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                e.setOrderID(rs.getString("OrderID"));
                e.setOrderDate(rs.getDate("OrderDate"));
                e.setCustomerID(rs.getString("CustomerID"));
                e.setEmployeeID(rs.getString("EmployeeID"));
                e.setTruckID(rs.getString("TruckID"));
                e.setIsSpecial(rs.getBoolean("IsSpecial"));
                e.setPurchaseOrderNumber(rs.getInt("PurchaseOrderNumber"));
                e.setOrderTotalAmount(rs.getDouble("OrderTotalAmount"));
                
                result.add(e);
            }
            stmt.close();
        } catch (Exception ex) {
            LOG.info("Error while fetching data");
            LOG.info("Error in getCustomerOrders" + ex.getMessage());
        }

        return result;
    }
    
    public List<Customer> customCustomerView(String cId, String phone, String businessName, String email, String contactName, Statement stmt) {
        Customer c = new Customer();
        List<Customer> cList = new ArrayList<Customer>();
        try {

            ResultSet rs = stmt.executeQuery("select * from customers where customerid='"+cId+"' or PhoneNumber='" + phone + "' or businessName='" + businessName
                    + "' or EmailAddress='" + email + "' or contactName='" + contactName + "'");
            LOG.info("select * from customers where phone='" + phone + "' or businessName='" + businessName + "' or email='" + email + "' or contactName='" + contactName + "'");
            while (rs.next()) {
                c.setCustomerID(rs.getString("CustomerID"));
                c.setTitle(rs.getString("Title"));
                c.setBusinessName(rs.getString("BusinessName"));
                c.setAddress(rs.getString("Address"));
                c.setCity(rs.getString("City"));
                c.setState(rs.getString("State"));
                c.setPostalCode(rs.getInt("PostalCode"));
                c.setCountry(rs.getString("Country"));
                c.setPhoneNumber(rs.getString("PhoneNumber"));
                c.setCellNumber(rs.getString("CellNumber"));
                c.setOtherNumber(rs.getString("OtherNumber"));
                c.setFaxNumber(rs.getString("FaxNumber"));
                c.setEmailAddress(rs.getString("EmailAddress"));
                c.setType(rs.getString("Type"));
                c.setName(rs.getString("CompanyName"));
                c.setContactName(rs.getString("ContactName"));
                c.setAlternateContactName(rs.getString("AlternateContactName"));
                c.setDateEntered(rs.getDate("DateEntered"));

                cList.add(c);
            }
            // LOG.info("test.Test.main()" + c.toString());
        } catch (Exception e) {
            LOG.info("Error in customCustomerView" + e.getMessage());
        }
        return cList;

    }

    public Boolean createEmployee(Employee c, Connection con){
        Boolean result = false;
        try {
            LOG.info("************************555555***");

            
            LOG.info(c.toString());
            
            String query= "insert into Employees values ('"+c.getEmployeeID()+"','"+c.getFirstName()+"','"+c.getLastName()+"','"+c.getEmail()+"','"+c.getExtension()+"','"+c.getHomePhone()+
                    "','"+c.getCellPhone()+"','"+c.getJobTitle()+"','"+c.getSocialSecurityNumber()+"',"+c.getSalary()+",'"+c.getDriverLicenseNumber()+"','"+c.getAddressLine1()+
                    "','"+c.getAddressLine2()+"','"+c.getCity()+"','"+c.getState()+"',"+c.getPostalCode()+",'"+c.getNotes()+"')";
            Statement stmt = con.createStatement();
            /*PreparedStatement stmt = con.prepareStatement("insert into Employees(EmployeeID,FirstName,LastName,Email,Extension,HomePhone,CellPhone,"
                    + "JobTitle,SocialSecurityNumber,Salary,DriverLicenseNumber,AddressLine1,AddressLine2,City,State,PostalCode,Notes)"
                    + " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            stmt.setString(1, c.getEmployeeID());
            stmt.setString(2, c.getFirstName());
            stmt.setString(3, c.getLastName());
            stmt.setString(4, c.getEmail());
            stmt.setString(5, c.getExtension());
            stmt.setString(6, c.getHomePhone());
            stmt.setString(7, c.getCellPhone());
            stmt.setString(8, c.getJobTitle());
            stmt.setString(9, c.getSocialSecurityNumber());
            stmt.setDouble(10, c.getSalary());
            stmt.setString(11, c.getDriverLicenseNumber());
            stmt.setString(12, c.getAddressLine1());
            stmt.setString(13, c.getAddressLine2());
            stmt.setString(14, c.getCity());
            stmt.setString(15, c.getState());
            stmt.setInt(16, c.getPostalCode());
            stmt.setString(17, c.getNotes());*/
            LOG.info("Query-----"+query);
            stmt.executeUpdate(query);
            //if (i == 1) {
                result=true;
                LOG.info("Data inserted successfully");
            //} else {
              //  result=false;
                //LOG.info("Data insert failed");
           // }

        } catch (Exception e) {
            result=false;
                LOG.info("Error while inserting data");
            LOG.info("Error in createEmployee" + e.getMessage());
            e.printStackTrace();
        }
        return result;
    }

    public Employee getEmployeeByID(String eID, Statement st) {
        Employee e = new Employee();
        try {

            ResultSet rs = st.executeQuery("select * from employees where employeeID= '" + eID + "'");
            while (rs.next()) {
                e.setEmployeeID(rs.getString("EmployeeID"));
                e.setFirstName(rs.getString("FirstName"));
                e.setLastName(rs.getString("LastName"));
                e.setEmail(rs.getString("Email"));
                e.setExtension(rs.getString("Extension"));
                e.setHomePhone(rs.getString("HomePhone"));
                e.setCellPhone(rs.getString("CellPhone"));
                e.setJobTitle(rs.getString("JobTitle"));
                e.setSocialSecurityNumber(rs.getString("SocialSecurityNumber"));
               // e.setDateHired(Date.valueOf(rs.getString("DateHired")));
                e.setSalary(rs.getDouble("Salary"));
                e.setDriverLicenseNumber(rs.getString("DriverLicenseNumber"));
                e.setAddressLine1(rs.getString("AddressLine1"));
                e.setAddressLine2(rs.getString("AddressLine1"));
                e.setCity(rs.getString("City"));
                e.setState(rs.getString("State"));
                e.setPostalCode(rs.getInt("PostalCode"));
              //  e.setBirthdate(Date.valueOf(rs.getString("Birthdate")));
                e.setNotes(rs.getString("Notes"));
            }
            LOG.info("test.Test.main()" + e.toString());
        } catch (Exception ex) {
            LOG.info("Error in getEmployeeID" + ex.getMessage());
        }
        return e;
    }

    public List<Employee> getAllEmployee(Statement st) {
        
        ArrayList<Employee> eList = new ArrayList<>();
        try {

            ResultSet rs = st.executeQuery("select * from soa.employees");
            while (rs.next()) {
                
                Employee e = new Employee();
                e.setEmployeeID(rs.getString("EmployeeID"));
                e.setFirstName(rs.getString("FirstName"));
                e.setLastName(rs.getString("LastName"));
                e.setEmail(rs.getString("Email"));
                e.setExtension(rs.getString("Extension"));
                e.setHomePhone(rs.getString("HomePhone"));
                e.setCellPhone(rs.getString("CellPhone"));
                e.setJobTitle(rs.getString("JobTitle"));
                e.setSocialSecurityNumber(rs.getString("SocialSecurityNumber"));
              //  e.setDateHired(new SimpleDateFormat("yyyy-MM-dd").parse(rs.getString("DateHired")));
                e.setSalary(rs.getDouble("Salary"));
                e.setDriverLicenseNumber(rs.getString("DriverLicenseNumber"));
                e.setAddressLine1(rs.getString("AddressLine1"));
                e.setAddressLine2(rs.getString("AddressLine1"));
                e.setCity(rs.getString("City"));
                e.setState(rs.getString("State"));
                e.setPostalCode(rs.getInt("PostalCode"));
              //  e.setBirthdate(new SimpleDateFormat("yyyy-MM-dd").parse(rs.getString("Birthdate")));
                e.setNotes(rs.getString("Notes"));

                LOG.info("333333333333333");
                eList.add(e);
                eList.size();
            }
        } catch (Exception ex) {
            LOG.info("$$$$$$$$$$");
            LOG.info("Error in getAllEmployee" + ex.getMessage());
        }
        return eList;
    }

    public Boolean updateEmployee(Employee c, Statement st) {
        Boolean result = false;
        LOG.info(c.toString());
        LOG.info("@@@@@@@@@@@@@@@@@");
        LOG.info("*****************8");
        try {
            String sql1 = "UPDATE soa.Employees set";
            if (c.getFirstName() != null) {
                sql1 = sql1 + " FirstName='" + c.getFirstName()+ "'";
            }
            if (c.getLastName()!= null) {
                sql1 = sql1 + ",LastName='" + c.getLastName()+ "'";
            }
            if (c.getEmail()!= null) {
                sql1 = sql1 + ",Email='" + c.getEmail()+ "'";
            }
            if (c.getExtension()!= null) {
                sql1 = sql1 + ",Extension='" + c.getExtension() + "'";
            }
            if (c.getHomePhone() != null) {
                sql1 = sql1 + ",HomePhone='" + c.getHomePhone() + "'";
            }
            if (c.getCellPhone() != null) {
                sql1 = sql1 + ",CellPhone=" + c.getCellPhone();
            }
            if (c.getJobTitle() != null) {
                sql1 = sql1 + ",JobTitle='" + c.getJobTitle() + "'";
            }
            if (c.getSocialSecurityNumber() != null) {
                sql1 = sql1 + ",SocialSecurityNumber='" + c.getSocialSecurityNumber() + "'";
            }
           /* if (c.getDateHired() != null) {
                sql1 = sql1 + ",DateHired='" + sdf.format(c.getDateHired()) + "'";
            }*/
            if (c.getSalary() != null) {
                sql1 = sql1 + ",Salary='" + c.getSalary() + "'";
            }
            if (c.getDriverLicenseNumber() != null) {
                sql1 = sql1 + ",DriverLicenseNumber='" + c.getDriverLicenseNumber() + "'";
            }
            if (c.getAddressLine1() != null) {
                sql1 = sql1 + ",AddressLine1='" + c.getAddressLine1() + "'";
            }
            if (c.getAddressLine2() != null) {
                sql1 = sql1 + ",AddressLine2='" + c.getAddressLine2() + "'";
            }
            if (c.getCity() != null) {
                sql1 = sql1 + ",City='" + c.getCity() + "'";
            }
            if (c.getState() != null) {
                sql1 = sql1 + ",State='" + c.getState() + "'";
            }
            if (c.getPostalCode() != 0) {
                sql1 = sql1 + ",PostalCode='" + c.getPostalCode() + "'";
            }
           /* if (c.getBirthdate() != null) {
                sql1 = sql1 + ",BirthDate='" + sdf.format(c.getBirthdate()) + "'";
            }*/
            if (c.getNotes() != null) {
                sql1 = sql1 + ",Notes='" + c.getNotes() + "'";
            }
            sql1 = sql1 + " where EmployeeID='" + c.getEmployeeID()+ "'";

            LOG.info("***************************************");
            LOG.info(sql1);
            st.executeUpdate(sql1);
            result = true;
            LOG.info("Data updated successfully");
        } catch (Exception e) {
            result = false;
            LOG.info("Error while inserting data");
            LOG.info("Error in Update Customer" + e.getMessage());
        }
        return result;
    }
    
    public Boolean deleteEmployee(String c, Connection con) {
      //  String result = "";
      Boolean result=false;
        try {

            PreparedStatement stmt = con.prepareStatement("delete from employees where employeeID=?");
            stmt.setString(1, c);

            int i = stmt.executeUpdate();
            if (i == 1) {
                LOG.info("Data deleted successfully");
                result=true;
            } else {
                LOG.info("Data deletion failed");
                result=false;
            }
            stmt.close();
        } catch (Exception e) {
            LOG.info("Error while inserting data");
            result=false;
            LOG.info("Error in delete Customer" + e.getMessage());
        }

        return result;
    }

    
   
    public List<Location> getAllLocation(Statement st) {
        
        List<Location> loc = new ArrayList<Location>();
        try {

            
            ResultSet rs = st.executeQuery("select * from locations");
            while (rs.next()) {
                Location e = new Location();
                e.setLocationID(rs.getString("LocationID"));
                e.setCustomerID(rs.getString("CustomerID"));
                e.setLocName(rs.getString("LocName"));
                e.setLocationCode(rs.getString("LocationCode"));
                e.setIsAuction(rs.getBoolean("IsAuction"));
                e.setAddressStreet1(rs.getString("AddressStreet1"));
                e.setAddressStreet2(rs.getString("AddressStreet2"));
                e.setCity(rs.getString("City"));
                e.setState(rs.getString("State"));
                e.setPostalCode(rs.getInt("PostalCode"));
                e.setRegion(rs.getString("Region"));
                e.setLocationContactName(rs.getString("LocationContactName"));
                e.setLocPhone(rs.getString("LocPhone"));
                e.setLocFaxNumber(rs.getString("LocFaxNumber"));
                e.setLocEmail(rs.getString("LocEmail"));

                loc.add(e);
            }
        } catch (Exception ex) {
            LOG.info("Error in getAllLocation" + ex.getMessage());
        }
        return loc;
    }

    public Pricing getPricingByID(String lID, Statement st) {
        Pricing e = new Pricing();
        try {

            ResultSet rs = st.executeQuery("select * from pricing where priceID= '" + lID + "'");
            while (rs.next()) {
                e.setPriceID(rs.getString("PriceID"));
                e.setPrice(rs.getDouble("Price"));
                e.setLocationIDFrom(rs.getString("LocationIDFrom"));
                e.setLocationIDTo(rs.getString("LocationIDTo"));
                e.setLocationCodeFrom(rs.getString("LocationCodeFrom"));
                e.setLocationCodeTo(rs.getString("LocationCodeTo"));
                e.setLocationNameFrom(rs.getString("LocationNameFrom"));
                e.setLocationNameTo(rs.getString("LocationNameTo"));
                e.setCustomerID(rs.getString("CustomerID"));

            }
            LOG.info("test.Test.main()" + e.toString());
        } catch (Exception ex) {
            LOG.info("Error in getLocationID" + ex.getMessage());
        }
        return e;
    }

    public List<Pricing> getAllPricing(Statement st) {
        List<Pricing> p = new ArrayList<Pricing>();
        
        try {

            ResultSet rs = st.executeQuery("select * from pricing");
            while (rs.next()) {
                Pricing e = new Pricing();
                e.setPriceID(rs.getString("PriceID"));
                e.setPrice(rs.getDouble("Price"));
                e.setLocationIDFrom(rs.getString("LocationIDFrom"));
                e.setLocationIDTo(rs.getString("LocationIDTo"));
                e.setLocationCodeFrom(rs.getString("LocationCodeFrom"));
                e.setLocationCodeTo(rs.getString("LocationCodeTo"));
                e.setLocationNameFrom(rs.getString("LocationNameFrom"));
                e.setLocationNameTo(rs.getString("LocationNameTo"));
                e.setCustomerID(rs.getString("CustomerID"));

                p.add(e);
            }
        } catch (Exception ex) {
            LOG.info("Error in getLocationID" + ex.getMessage());
        }
        return p;
    }

    public List<Truck> getAllTrucks(Statement st) {
        List<Truck> p = new ArrayList<Truck>();
        
        try {

            ResultSet rs = st.executeQuery("select * from trucks");
            while (rs.next()) {
                Truck e = new Truck();
                e.setTruckNo(rs.getString("TruckNo"));
                e.setMake(rs.getString("Make"));
                e.setYear(rs.getString("Year"));
                e.setModel(rs.getString("Model"));
                e.setColor(rs.getString("Color"));
                e.setLicensePlateNo(rs.getString("LicensePlateNo"));
                e.setEmployeeID(rs.getString("EmployeeID"));
                e.setVin(rs.getString("VIN"));

                p.add(e);
            }
        } catch (Exception ex) {
            LOG.info("Error in getLocationID" + ex.getMessage());
        }
        return p;
    }

    public Truck getTrucksByID(String tID, Statement st) {
        Truck e = new Truck();
        try {

            ResultSet rs = st.executeQuery("select * from trucks where TruckNO= '" + tID + "'");
            while (rs.next()) {
                e.setTruckNo(rs.getString("TruckNo"));
                e.setMake(rs.getString("Make"));
                e.setYear(rs.getString("Year"));
                e.setModel(rs.getString("Model"));
                e.setColor(rs.getString("Color"));
                e.setLicensePlateNo(rs.getString("LicensePlateNo"));
                e.setEmployeeID(rs.getString("EmployeeID"));
                e.setVin(rs.getString("VIN"));

            }
            LOG.info("test.Test.main()" + e.toString());
        } catch (Exception ex) {
            LOG.info("Error in getLocationID" + ex.getMessage());
        }
        return e;
    }

    public Expenses getExpenseByID(String tID, Statement st) {
        Expenses e = new Expenses();
        try {

            ResultSet rs = st.executeQuery("select * from expenses where ExpenseID= '" + tID + "'");
            while (rs.next()) {
                e.setExpenseID(rs.getString("ExpenseID"));
                e.setEmployeeID(rs.getString("EmployeeID"));
                e.setExpenseType(rs.getString("ExpenseType"));
                e.setPurposeofExpense(rs.getString("PurposeofExpense"));
                e.setAmountSpent(rs.getDouble("AmountSpent"));
                e.setDescription(rs.getString("Description"));
                e.setDatePurchased(rs.getDate("DatePurchased"));
                e.setDateSubmitted(rs.getDate("DateSubmitted"));
                e.setAdvanceAmount(rs.getDouble("AdvanceAmount"));
                e.setPaymentMethod(rs.getString("PaymentMethod"));
            }
            LOG.info("test.Test.main()" + e.toString());
        } catch (Exception ex) {
            LOG.info("Error in getExpenseByID" + ex.getMessage());
        }
        return e;
    }

    public List<Expenses> getAllExpenses(Statement st) {
        List<Expenses> p = new ArrayList<Expenses>();
        
        try {

            ResultSet rs = st.executeQuery("select * from Expenses");
            while (rs.next()) {
                Expenses e = new Expenses();
                e.setExpenseID(rs.getString("ExpenseID"));
                e.setEmployeeID(rs.getString("EmployeeID"));
                e.setExpenseType(rs.getString("ExpenseType"));
                e.setPurposeofExpense(rs.getString("PurposeofExpense"));
                e.setAmountSpent(rs.getDouble("AmountSpent"));
                e.setDescription(rs.getString("Description"));
                e.setDatePurchased(rs.getDate("DatePurchased"));
                e.setDateSubmitted(rs.getDate("DateSubmitted"));
                e.setAdvanceAmount(rs.getDouble("AdvanceAmount"));
                e.setPaymentMethod(rs.getString("PaymentMethod"));

                p.add(e);
            }
        } catch (Exception ex) {
            LOG.info("Error in getAllExpenses" + ex.getMessage());
        }
        return p;
    }

    public Orders getOrderById(String tID, Statement st) {
        Orders e = new Orders();
        try {

            ResultSet rs = st.executeQuery("select * from Orders where OrderID= '" + tID + "'");
            while (rs.next()) {
                e.setOrderID(rs.getString("OrderID"));
                e.setOrderDate(rs.getDate("OrderDate"));
                e.setCustomerID(rs.getString("CustomerID"));
                e.setEmployeeID(rs.getString("EmployeeID"));
                e.setTruckID(rs.getString("TruckID"));
                e.setIsSpecial(rs.getBoolean("IsSpecial"));
                e.setPurchaseOrderNumber(rs.getInt("PurchaseOrderNumber"));
                e.setOrderTotalAmount(rs.getDouble("OrderTotalAmount"));
            }
            LOG.info("test.Test.main()" + e.toString());
        } catch (Exception ex) {
            LOG.info("Error in getOrderById" + ex.getMessage());
        }
        return e;
    }

    public List<Orders> getAllOrders(Statement st) {
        List<Orders> p = new ArrayList<Orders>();
        
        try {

            ResultSet rs = st.executeQuery("select * from Orders");
            while (rs.next()) {
                Orders e = new Orders();
                e.setOrderID(rs.getString("OrderID"));
                e.setOrderDate(rs.getDate("OrderDate"));
                e.setCustomerID(rs.getString("CustomerID"));
                e.setEmployeeID(rs.getString("EmployeeID"));
                e.setTruckID(rs.getString("TruckID"));
                e.setIsSpecial(rs.getBoolean("IsSpecial"));
                e.setPurchaseOrderNumber(rs.getInt("PurchaseOrderNumber"));
                e.setOrderTotalAmount(rs.getDouble("OrderTotalAmount"));

                p.add(e);
            }
        } catch (Exception ex) {
            LOG.info("Error in getAllOrders" + ex.getMessage());
        }
        return p;
    }

    public Transactions getTransactionById(String tID, Statement st) {
        Transactions e = new Transactions();
        try {

            ResultSet rs = st.executeQuery("select * from Transactions where TransactionID= '" + tID + "'");
            while (rs.next()) {
                e.setTransactionID(rs.getString("TransactionID"));
                e.setOrderID(rs.getString("OrderID"));
                e.setPriceID(rs.getString("PriceID"));
                e.setTransactionDate(rs.getDate("TransactionDate"));
                e.setTransactionDescription(rs.getString("TransactionDescription"));
                e.setTransactionAmount(rs.getDouble("TransactionAmount"));
                e.setMake(rs.getString("make"));
                e.setYear(rs.getString("year"));
                e.setEmployeeID(rs.getString("EmployeeID"));
                e.setTruckNo(rs.getString("TruckNo"));
                e.setDiscount(rs.getDouble("discount"));
                e.setQuantity(rs.getInt("quantity"));
                e.setUnitPrice(rs.getDouble("unitPrice"));
                e.setDriverPrice(rs.getDouble("driverPrice"));
                e.setVIN(rs.getString("VIN"));
                e.setRunNumber(rs.getInt("runNumber"));
                e.setSpecial(rs.getBoolean("special"));
                e.setRate(rs.getDouble("rate"));
                e.setSurcharge(rs.getDouble("Surcharge"));
            }
            LOG.info("test.Test.main()" + e.toString());
        } catch (Exception ex) {
            LOG.info("Error in getTransactionById" + ex.getMessage());
        }
        return e;
    }

    public List<Transactions> getAllTransactions(Statement st) {
        List<Transactions> p = new ArrayList<Transactions>();
        
        try {

            ResultSet rs = st.executeQuery("select * from Transactions");
            while (rs.next()) {
                Transactions e = new Transactions();
                e.setTransactionID(rs.getString("TransactionID"));
                e.setOrderID(rs.getString("OrderID"));
                e.setPriceID(rs.getString("PriceID"));
                e.setTransactionDate(rs.getDate("TransactionDate"));
                e.setTransactionDescription(rs.getString("TransactionDescription"));
                e.setTransactionAmount(rs.getDouble("TransactionAmount"));
                e.setMake(rs.getString("make"));
                e.setYear(rs.getString("year"));
                e.setEmployeeID(rs.getString("EmployeeID"));
                e.setTruckNo(rs.getString("TruckNo"));
                e.setDiscount(rs.getDouble("discount"));
                e.setQuantity(rs.getInt("quantity"));
                e.setUnitPrice(rs.getDouble("unitPrice"));
                e.setDriverPrice(rs.getDouble("driverPrice"));
                e.setVIN(rs.getString("VIN"));
                e.setRunNumber(rs.getInt("runNumber"));
                e.setSpecial(rs.getBoolean("special"));
                e.setRate(rs.getDouble("rate"));
                e.setSurcharge(rs.getDouble("Surcharge"));

                p.add(e);
            }
        } catch (Exception ex) {
            LOG.info("Error in getAllTransactions" + ex.getMessage());
        }
        return p;
    }

    public Payments getPaymentById(String tID, Statement st) {
        Payments e = new Payments();
        try {

            ResultSet rs = st.executeQuery("select * from Payments where PaymentID= '" + tID + "'");
            while (rs.next()) {
                e.setPaymentID(rs.getString("PaymentID"));
                e.setOrderID(rs.getString("OrderID"));
                e.setPaymentMethodID(rs.getString("PaymentMethodID"));
                e.setPaymentAmount(rs.getDouble("PaymentAmount"));
                e.setPaymentDate(rs.getDate("PaymentDate"));
                e.setCheckNumber(rs.getString("CheckNumber"));
                e.setCreditCard(rs.getString("CreditCard"));
                e.setCreditCardNumber(rs.getString("CreditCardNumber"));
                e.setCreditCardHoldersName(rs.getString("CreditCardHoldersName"));
                e.setCreditCardExpDate(rs.getString("CreditCardExpDate"));
                e.setCreditCardAuthorizedName(rs.getInt("CreditCardAuthorizedName"));
            }
            LOG.info("test.Test.main()" + e.toString());
        } catch (Exception ex) {
            LOG.info("Error in getPaymentById" + ex.getMessage());
        }
        return e;
    }

    public List<Payments> getAllPayments(Statement st) {
        List<Payments> p = new ArrayList<Payments>();
        
        try {

            ResultSet rs = st.executeQuery("select * from Payments");
            while (rs.next()) {
                Payments e = new Payments();
                e.setPaymentID(rs.getString("PaymentID"));
                e.setOrderID(rs.getString("OrderID"));
                e.setPaymentMethodID(rs.getString("PaymentMethodID"));
                e.setPaymentAmount(rs.getDouble("PaymentAmount"));
                e.setPaymentDate(rs.getDate("PaymentDate"));
                e.setCheckNumber(rs.getString("CheckNumber"));
                e.setCreditCard(rs.getString("CreditCard"));
                e.setCreditCardNumber(rs.getString("CreditCardNumber"));
                e.setCreditCardHoldersName(rs.getString("CreditCardHoldersName"));
                e.setCreditCardExpDate(rs.getString("CreditCardExpDate"));
                e.setCreditCardAuthorizedName(rs.getInt("CreditCardAuthorizedName"));

                p.add(e);
            }
        } catch (Exception ex) {
            LOG.info("Error in getAllPayments" + ex.getMessage());
        }
        return p;
    }

    public Invoices getInvoiceById(String tID, Statement st) {
        Invoices e = new Invoices();
        try {

            ResultSet rs = st.executeQuery("select * from Invoice where InvoiceID= '" + tID + "'");
            while (rs.next()) {
                e.setInvoiceID(rs.getString("InvoiceID"));
                e.setOrderID(rs.getString("OrderID"));
                e.setEmployeeID(rs.getString("EmployeeID"));
                e.setCustomerID(rs.getString("CustomerID"));
                e.setDescription(rs.getString("Description"));
                e.setPrice(rs.getDouble("Price"));
                e.setQuantity(rs.getInt("Quantity"));
            }
            LOG.info("test.Test.main()" + e.toString());
        } catch (Exception ex) {
            LOG.info("Error in getInvoiceById" + ex.getMessage());
        }
        return e;
    }

    public List<Invoices> getAllInvoices(Statement st) {
        List<Invoices> p = new ArrayList<Invoices>();
        
        try {

            ResultSet rs = st.executeQuery("select * from Invoice");
            while (rs.next()) {
                Invoices e = new Invoices();
                e.setInvoiceID(rs.getString("InvoiceID"));
                e.setOrderID(rs.getString("OrderID"));
                e.setEmployeeID(rs.getString("EmployeeID"));
                e.setCustomerID(rs.getString("CustomerID"));
                e.setDescription(rs.getString("Description"));
                e.setPrice(rs.getDouble("Price"));
                e.setQuantity(rs.getInt("Quantity"));

                p.add(e);
            }
        } catch (Exception ex) {
            LOG.info("Error in getAllInvoices" + ex.getMessage());
        }
        return p;
    }

    public Comments getCommentById(String tID, Statement st) {
        Comments e = new Comments();
        try {

            ResultSet rs = st.executeQuery("select * from Comments where CommentID= '" + tID + "'");
            while (rs.next()) {
                e.setCommentID(rs.getString("CommentID"));
                e.setCustomerID(rs.getString("CustomerID"));
                e.setLocationID(rs.getString("LocationID"));
                e.setTransactionID(rs.getString("TransactionID"));
                e.setCommentTime(rs.getTime("CommentTime"));
                e.setCommentLine(rs.getString("CommentLine"));
            }
            LOG.info("test.Test.main()" + e.toString());
        } catch (Exception ex) {
            LOG.info("Error in getCommentById" + ex.getMessage());
        }
        return e;
    }

    public List<Comments> getAllComments(Statement st) {
        List<Comments> p = new ArrayList<Comments>();
        
        try {

            ResultSet rs = st.executeQuery("select * from Comments");
            while (rs.next()) {
                Comments e = new Comments();
                e.setCommentID(rs.getString("CommentID"));
                e.setCustomerID(rs.getString("CustomerID"));
                e.setLocationID(rs.getString("LocationID"));
                e.setTransactionID(rs.getString("TransactionID"));
                e.setCommentTime(rs.getTime("CommentTime"));
                e.setCommentLine(rs.getString("CommentLine"));

                p.add(e);
            }
        } catch (Exception ex) {
            LOG.info("Error in getAllComments" + ex.getMessage());
        }
        return p;
    }
}
