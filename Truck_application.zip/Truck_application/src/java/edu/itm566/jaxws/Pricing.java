/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.itm566.jaxws;

import java.util.logging.Logger;

/**
 *
 * @author varsh
 */
public class Pricing {

    private String PriceID;
    private Double Price;
    private String LocationIDFrom;
    private String LocationIDTo;
    private String LocationCodeFrom;
    private String LocationCodeTo;
    private String LocationNameFrom;
    private String LocationNameTo;
    private String CustomerID;

    private static final Logger LOG = Logger.getLogger(Pricing.class.getName());

    public Pricing() {
    }

    public String getPriceID() {
        return PriceID;
    }

    public void setPriceID(String PriceID) {
        this.PriceID = PriceID;
    }

    public Double getPrice() {
        return Price;
    }

    public void setPrice(Double Price) {
        this.Price = Price;
    }

    public String getLocationIDFrom() {
        return LocationIDFrom;
    }

    public void setLocationIDFrom(String LocationIDFrom) {
        this.LocationIDFrom = LocationIDFrom;
    }

    public String getLocationIDTo() {
        return LocationIDTo;
    }

    public void setLocationIDTo(String LocationIDTo) {
        this.LocationIDTo = LocationIDTo;
    }

    public String getLocationCodeFrom() {
        return LocationCodeFrom;
    }

    public void setLocationCodeFrom(String LocationCodeFrom) {
        this.LocationCodeFrom = LocationCodeFrom;
    }

    public String getLocationCodeTo() {
        return LocationCodeTo;
    }

    public void setLocationCodeTo(String LocationCodeTo) {
        this.LocationCodeTo = LocationCodeTo;
    }

    public String getLocationNameFrom() {
        return LocationNameFrom;
    }

    public void setLocationNameFrom(String LocationNameFrom) {
        this.LocationNameFrom = LocationNameFrom;
    }

    public String getLocationNameTo() {
        return LocationNameTo;
    }

    public void setLocationNameTo(String LocationNameTo) {
        this.LocationNameTo = LocationNameTo;
    }

    public String getCustomerID() {
        return CustomerID;
    }

    public void setCustomerID(String CustomerID) {
        this.CustomerID = CustomerID;
    }

    @Override
    public String toString() {
        return "Pricing{" + "PriceID=" + PriceID + ", Price=" + Price + ", LocationIDFrom=" + LocationIDFrom + ", LocationIDTo=" + LocationIDTo + ", LocationCodeFrom=" + LocationCodeFrom + ", LocationCodeTo=" + LocationCodeTo + ", LocationNameFrom=" + LocationNameFrom + ", LocationNameTo=" + LocationNameTo + ", CustomerID=" + CustomerID + '}';
    }
    
    
}
