/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.itm566.jaxws;


import java.util.Date;
import java.util.logging.Logger;

/**
 *
 * @author varsh
 */
public class Employee {
    private String EmployeeID;
    private String FirstName;
    private String LastName;
    private String Email;
    private String Extension;
    private String HomePhone;
    private String CellPhone;
    private String JobTitle;
    private String SocialSecurityNumber;
    private Date DateHired;
    private Double Salary;
    private String DriverLicenseNumber;
    private String AddressLine1;
    private String AddressLine2;
    private String City;
    private String State;
    private int PostalCode;
    private Date Birthdate;
    private String Notes;
    
    private static final Logger LOG = Logger.getLogger(Employee.class.getName());

    public Employee() {
    }

    public Employee(String EmployeeID, String FirstName, String LastName, String Email, String Extension, String HomePhone, String CellPhone, String JobTitle, String SocialSecurityNumber, Date DateHired, Double Salary, String DriverLicenseNumber, String AddressLine1, String AddressLine2, String City, String State, int PostalCode, Date Birthdate, String Notes) {
        this.EmployeeID = EmployeeID;
        this.FirstName = FirstName;
        this.LastName = LastName;
        this.Email = Email;
        this.Extension = Extension;
        this.HomePhone = HomePhone;
        this.CellPhone = CellPhone;
        this.JobTitle = JobTitle;
        this.SocialSecurityNumber = SocialSecurityNumber;
        this.DateHired = DateHired;
        this.Salary = Salary;
        this.DriverLicenseNumber = DriverLicenseNumber;
        this.AddressLine1 = AddressLine1;
        this.AddressLine2 = AddressLine2;
        this.City = City;
        this.State = State;
        this.PostalCode = PostalCode;
        this.Birthdate = Birthdate;
        this.Notes = Notes;
    }

    public String getEmployeeID() {
        return EmployeeID;
    }

    public void setEmployeeID(String EmployeeID) {
        this.EmployeeID = EmployeeID;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String FirstName) {
        this.FirstName = FirstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getExtension() {
        return Extension;
    }

    public void setExtension(String Extension) {
        this.Extension = Extension;
    }

    public String getHomePhone() {
        return HomePhone;
    }

    public void setHomePhone(String HomePhone) {
        this.HomePhone = HomePhone;
    }

    public String getCellPhone() {
        return CellPhone;
    }

    public void setCellPhone(String CellPhone) {
        this.CellPhone = CellPhone;
    }

    public String getJobTitle() {
        return JobTitle;
    }

    public void setJobTitle(String JobTitle) {
        this.JobTitle = JobTitle;
    }

    public String getSocialSecurityNumber() {
        return SocialSecurityNumber;
    }

    public void setSocialSecurityNumber(String SocialSecurityNumber) {
        this.SocialSecurityNumber = SocialSecurityNumber;
    }

    public Date getDateHired() {
        return DateHired;
    }

    public void setDateHired(Date DateHired) {
        this.DateHired = DateHired;
    }

    public Double getSalary() {
        return Salary;
    }

    public void setSalary(Double Salary) {
        this.Salary = Salary;
    }

    public String getDriverLicenseNumber() {
        return DriverLicenseNumber;
    }

    public void setDriverLicenseNumber(String DriverLicenseNumber) {
        this.DriverLicenseNumber = DriverLicenseNumber;
    }

    public String getAddressLine1() {
        return AddressLine1;
    }

    public void setAddressLine1(String AddressLine1) {
        this.AddressLine1 = AddressLine1;
    }

    public String getAddressLine2() {
        return AddressLine2;
    }

    public void setAddressLine2(String AddressLine2) {
        this.AddressLine2 = AddressLine2;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String City) {
        this.City = City;
    }

    public String getState() {
        return State;
    }

    public void setState(String State) {
        this.State = State;
    }

    public int getPostalCode() {
        return PostalCode;
    }

    public void setPostalCode(int PostalCode) {
        this.PostalCode = PostalCode;
    }

    public Date getBirthdate() {
        return Birthdate;
    }

    public void setBirthdate(Date Birthdate) {
        this.Birthdate = Birthdate;
    }

    public String getNotes() {
        return Notes;
    }

    public void setNotes(String Notes) {
        this.Notes = Notes;
    }

    @Override
    public String toString() {
        return "Employee{" + "EmployeeID=" + EmployeeID + ", FirstName=" + FirstName + ", LastName=" + LastName + ", Email=" + Email + ", Extension=" + Extension + ", HomePhone=" + HomePhone + ", CellPhone=" + CellPhone + ", JobTitle=" + JobTitle + ", SocialSecurityNumber=" + SocialSecurityNumber + ", DateHired=" + DateHired + ", Salary=" + Salary + ", DriverLicenseNumber=" + DriverLicenseNumber + ", AddressLine1=" + AddressLine1 + ", AddressLine2=" + AddressLine2 + ", City=" + City + ", State=" + State + ", PostalCode=" + PostalCode + ", Birthdate=" + Birthdate + ", Notes=" + Notes + '}';
    }
    
    
}
