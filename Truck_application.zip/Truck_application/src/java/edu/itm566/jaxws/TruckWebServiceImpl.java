/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.itm566.jaxws;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author varsh
 */
@WebService(name = "TruckCatalog", portName = "TruckCatalogPort", serviceName = "TruckWebService")
public class TruckWebServiceImpl{

    /**
     * This is a sample web service operation
     */
    private static final Logger LOG = Logger.getLogger(TruckWebServiceImpl.class.getName());

    
    
    @WebMethod(operationName = "getCustomerByID")
    public Customer getCustomerByID(@WebParam(name = "name") String txt) {

        Customer c = new Customer();
        DBConnection dB = new DBConnection();

        try {
            System.out.println(1);
            Connection con = dB.getDbConnection();
            Statement st = con.createStatement();

            System.out.println(1);
            DBSelectHelper helper = new DBSelectHelper();
            c = helper.getCustomerByID(txt, st);
            st.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return c;
    }
    
    @WebMethod(operationName = "getAllCustomers")
    public List<Customer> getAllCustomers() {

        List<Customer> c = new ArrayList<Customer>();
        DBConnection dB = new DBConnection();

        try {
            System.out.println(1);
            Connection con = dB.getDbConnection();
            Statement st = con.createStatement();

            System.out.println(1);
            DBSelectHelper helper = new DBSelectHelper();
           c = helper.getAllCustomers(st);
            st.close();
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return c;
    }
    
    
    @WebMethod(operationName = "createCustomer")
    public Boolean createCustomer(@WebParam(name = "Customer")Customer cData) {

        LOG.info(cData.toString());
        DBConnection dB = new DBConnection();
        Boolean result=false;
        try {
            System.out.println(1);
            Connection con = dB.getDbConnection();
            Statement st = con.createStatement();

            System.out.println(1);
            DBSelectHelper helper = new DBSelectHelper();
            result = helper.createCustomer(cData,con);
            st.close();
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return result;
    }
    
    @WebMethod(operationName = "deleteCustomer")
    public Boolean deleteCustomer(@WebParam(name = "CustomerID")String cData) {

        LOG.info(cData.toString());
        DBConnection dB = new DBConnection();
        Boolean result=false;
        try {
            System.out.println(1);
            Connection con = dB.getDbConnection();
           // Statement st = con.createStatement();

            System.out.println(1);
            DBSelectHelper helper = new DBSelectHelper();
            result = helper.deleteCustomer(cData,con);
           // st.close();
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return result;
    }
    
    @WebMethod(operationName = "customCustomerView")
    public List<Customer> customCustomerView(@WebParam(name = "CustomerID")String cId,
            @WebParam(name = "Phone")String phone,
            @WebParam(name="BusinessName")String businessName,
            @WebParam(name = "Email")String email,
            @WebParam(name = "ContactName")String contactName)
    {
        List<Customer> c = new ArrayList<Customer>();
        DBConnection dB = new DBConnection();

        try {
            System.out.println(1);
            Connection con = dB.getDbConnection();
            Statement st = con.createStatement();

            System.out.println(1);
            DBSelectHelper helper = new DBSelectHelper();
            c = helper.customCustomerView(cId,phone, businessName, email, contactName,st);
            st.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return c;
    }
    @WebMethod(operationName = "updateCustomer")
    public String updateCustomer(@WebParam(name = "Customer")Customer cData) {

        LOG.info(cData.toString());
        DBConnection dB = new DBConnection();
        String result="";
        try {
            System.out.println(1);
            Connection con = dB.getDbConnection();
            Statement st = con.createStatement();

            System.out.println(1);
            DBSelectHelper helper = new DBSelectHelper();
            result = helper.updateCustomer(cData,st);
            st.close();
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return result;
    }
    
    @WebMethod(operationName = "getCustomerOrders")
    public List<Orders> getCustomerOrders(@WebParam(name = "CustomerID")String cID) {

        LOG.info(cID.toString());
        DBConnection dB = new DBConnection();
        List<Orders> result= new ArrayList<Orders>();
        try {
            System.out.println(1);
            Connection con = dB.getDbConnection();
            LOG.info("Inside getCustomerOrders");
            DBSelectHelper helper = new DBSelectHelper();
            result = helper.getCustomerOrders(cID,con);
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return result;
    }
    
    @WebMethod(operationName = "createEmployee")
    public Boolean createEmployee(@WebParam(name = "Employee")Employee emp) {

        LOG.info(emp.toString());
        DBConnection dB = new DBConnection();
        Boolean result=false;
        try {
            System.out.println(1);
            Connection con = dB.getDbConnection();
            Statement st = con.createStatement();

            System.out.println(1);
            DBSelectHelper helper = new DBSelectHelper();
            result = helper.createEmployee(emp,con);
            st.close();
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return result;
    }

    @WebMethod(operationName = "getEmployeeByID")
    public Employee getEmployeeByID(@WebParam(name = "name") String txt) {

        Employee e = new Employee();
        DBConnection dB = new DBConnection();

        try {
            System.out.println(1);
            Connection con = dB.getDbConnection();
            Statement st = con.createStatement();

            System.out.println(1);
            DBSelectHelper helper = new DBSelectHelper();
            e = helper.getEmployeeByID(txt, st);
            st.close();
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return e;
    }
    
    @WebMethod(operationName = "getAllEmployee")
    public List<Employee> getAllEmployee() {

        List<Employee> e = new ArrayList<Employee>();
        DBConnection dB = new DBConnection();

        try {
            System.out.println(1);
            Connection con = dB.getDbConnection();
            Statement st = con.createStatement();

            System.out.println(1);
            DBSelectHelper helper = new DBSelectHelper();
            e = helper.getAllEmployee(st);
            st.close();
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return e;
    }
    
    @WebMethod(operationName = "deleteEmployee")
    public Boolean deleteEmployee(@WebParam(name = "EmployeeId")String cData) {

        LOG.info(cData.toString());
        DBConnection dB = new DBConnection();
        Boolean result=false;
        try {
            System.out.println(1);
            Connection con = dB.getDbConnection();
           // Statement st = con.createStatement();

            System.out.println(1);
            DBSelectHelper helper = new DBSelectHelper();
            result = helper.deleteEmployee(cData,con);
           // st.close();
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return result;
    }

    @WebMethod(operationName = "updateEmployee")
    public Boolean updateEmployee(@WebParam(name = "Employee")Employee cData) {

        LOG.info(cData.toString());
        DBConnection dB = new DBConnection();
        Boolean result=false;
        try {
            System.out.println(1);
            Connection con = dB.getDbConnection();
            Statement st = con.createStatement();

            System.out.println(1);
            DBSelectHelper helper = new DBSelectHelper();
            result = helper.updateEmployee(cData,st);
            st.close();
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return result;
    }
    
    @WebMethod(operationName = "getAllLocation")
    public List<Location> getAllLocation() {

        List<Location> l = new ArrayList<Location>();
        DBConnection dB = new DBConnection();

        try {
            System.out.println(1);
            Connection con = dB.getDbConnection();
            Statement st = con.createStatement();

            System.out.println(1);
            DBSelectHelper helper = new DBSelectHelper();
            l = helper.getAllLocation(st);
            st.close();
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return l;
    }
    
    @WebMethod(operationName = "getAllPricing")
    public List<Pricing> getAllPricing() {

        List<Pricing> l = new ArrayList<Pricing>();
        DBConnection dB = new DBConnection();

        try {
            System.out.println(1);
            Connection con = dB.getDbConnection();
            Statement st = con.createStatement();

            System.out.println(1);
            DBSelectHelper helper = new DBSelectHelper();
            l = helper.getAllPricing(st);
            st.close();
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return l;
    }
    
    @WebMethod(operationName = "getAllTrucks")
    public List<Truck> getAllTrucks() {

        List<Truck> l = new ArrayList<Truck>();
        DBConnection dB = new DBConnection();

        try {
            System.out.println(1);
            Connection con = dB.getDbConnection();
            Statement st = con.createStatement();

            System.out.println(1);
            DBSelectHelper helper = new DBSelectHelper();
            l = helper.getAllTrucks(st);
            st.close();
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return l;
    }

    @WebMethod(operationName = "getAllExpenses")
    public List<Expenses> getAllExpenses() {

        List<Expenses> l = new ArrayList<Expenses>();
        DBConnection dB = new DBConnection();

        try {
            System.out.println(1);
            Connection con = dB.getDbConnection();
            Statement st = con.createStatement();

            System.out.println(1);
            DBSelectHelper helper = new DBSelectHelper();
            l = helper.getAllExpenses(st);
            st.close();
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return l;
    }

    @WebMethod(operationName = "getOrderById")
    public String getOrderById(@WebParam(name = "name") String txt) {

        Orders l = new Orders();
        DBConnection dB = new DBConnection();

        try {
            System.out.println(1);
            Connection con = dB.getDbConnection();
            Statement st = con.createStatement();

            System.out.println(1);
            DBSelectHelper helper = new DBSelectHelper();
            l = helper.getOrderById(txt,st);
            st.close();
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return l.toString();
    }

    @WebMethod(operationName = "getAllOrders")
    public List<Orders> getAllOrders() {

        List<Orders> l = new ArrayList<Orders>();
        DBConnection dB = new DBConnection();

        try {
            System.out.println(1);
            Connection con = dB.getDbConnection();
            Statement st = con.createStatement();

            System.out.println(1);
            DBSelectHelper helper = new DBSelectHelper();
            l = helper.getAllOrders(st);
            st.close();
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return l;
    }

    @WebMethod(operationName = "getAllTransactions")
    public List<Transactions> getAllTransactions() {

        List<Transactions> l = new ArrayList<Transactions>();
        DBConnection dB = new DBConnection();

        try {
            System.out.println(1);
            Connection con = dB.getDbConnection();
            Statement st = con.createStatement();

            System.out.println(1);
            DBSelectHelper helper = new DBSelectHelper();
            l = helper.getAllTransactions(st);
            st.close();
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return l;
    }

    @WebMethod(operationName = "getAllPayments")
    public List<Payments> getAllPayments() {

        List<Payments> l = new ArrayList<Payments>();
        DBConnection dB = new DBConnection();

        try {
            System.out.println(1);
            Connection con = dB.getDbConnection();
            Statement st = con.createStatement();

            System.out.println(1);
            DBSelectHelper helper = new DBSelectHelper();
            l = helper.getAllPayments(st);
            st.close();
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return l;
    }

    @WebMethod(operationName = "getAllInvoices")
    public List<Invoices> getAllInvoices() {

        List<Invoices> l = new ArrayList<Invoices>();
        DBConnection dB = new DBConnection();

        try {
            System.out.println(1);
            Connection con = dB.getDbConnection();
            Statement st = con.createStatement();

            System.out.println(1);
            DBSelectHelper helper = new DBSelectHelper();
            l = helper.getAllInvoices(st);
            st.close();
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return l;
    }

    @WebMethod(operationName = "getCommentById")
    public String getCommentById(@WebParam(name = "name") String txt) {

        Comments l = new Comments();
        DBConnection dB = new DBConnection();

        try {
            System.out.println(1);
            Connection con = dB.getDbConnection();
            Statement st = con.createStatement();

            System.out.println(1);
            DBSelectHelper helper = new DBSelectHelper();
            l = helper.getCommentById(txt,st);
            st.close();
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return l.toString();
    }

    @WebMethod(operationName = "getAllComments")
    public List<Comments> getAllComments() {

        List<Comments> l = new ArrayList<Comments>();
        DBConnection dB = new DBConnection();

        try {
            System.out.println(1);
            Connection con = dB.getDbConnection();
            Statement st = con.createStatement();

            System.out.println(1);
            DBSelectHelper helper = new DBSelectHelper();
            l = helper.getAllComments(st);
            st.close();
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return l;
    }
}
